#include <stdio.h>
#include <stdlib.h>
#include <libgen.h>
#include <string.h>

int main( int argc, char **argv )
{
    int failure = 0;

    if( strcmp( dirname( "C:\\Hello\\World\\TEST.C" ),
                "C:\\Hello\\World" ) != 0 ) {
        printf( "dirname() - Failure\n" );
        failure++;
    } else printf( "dirname() - Success\n" );

    if( strcmp( dirname( "C:/Hello/World/TEST.C" ), "C:/Hello/World" ) != 0 ) {
        printf( "dirname() (2) - Failure\n" );
        failure++;
    } else printf( "dirname() (2) - Success\n" );

    if( strcmp( basename( "C:\\Hello\\World\\TEST.C" ), "TEST.C" ) != 0 ) {
        printf( "basename() - Failure\n" );
        failure++;
    } else printf( "basename() - Success\n" );

    if( strcmp( basename( "C:/Hello/World/TEST.C" ), "TEST.C" ) != 0 ) {
        printf( "basename() (2) - Failure\n" );
        failure++;
    } else printf( "basename() (2) - Success\n" );

    return( failure );
}

