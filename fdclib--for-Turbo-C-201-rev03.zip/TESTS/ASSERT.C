#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <process.h>

int main( int argc, char **argv )
{
    printf( "Assert.lib\n" );
    if( spawnl( P_WAIT, "ASSERT1", "ASSERT1", NULL ) == 0 ) {
        printf( "Failure\n" );

        return( EXIT_FAILURE );
    }

    printf( "Success\n" );

    return( EXIT_SUCCESS );
}

