#include <assert.h>
#include <stdlib.h>

int main( int argc, char **argv )
{
    assert( NULL );

    return( EXIT_SUCCESS ); /* Will be interpreted as failure */
}

