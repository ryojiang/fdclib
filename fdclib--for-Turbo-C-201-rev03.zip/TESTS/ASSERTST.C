/* ASSERTST.C: Add an item to a list,
verify that the item is not NULL */
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

struct ITEM {
    int key;
    int value;
} ITEM;

void additem(struct ITEM *itemptr)
{
    assert(itemptr != NULL);
    /* ... add the item ... */
}

int main(void)
{
    additem(NULL);
    return 0;
}