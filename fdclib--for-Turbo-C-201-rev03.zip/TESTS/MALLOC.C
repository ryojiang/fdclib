#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main( int argc, char **argv )
{
    int failure = 0;
    char *ptr = malloc( 15 );
    char *ptr2 = malloc( 15 );
    char far *fptr = _fmalloc( 15 );
    char far *fptr2 = _fmalloc( 15 );

    strcpy( ptr, "Hello, world.\n" );
    strcpy( ptr2, "Hello, again.\n" );
    _fstrcpy( fptr, "Hello, world.\n" );
    _fstrcpy( fptr2, "Hello, again.\n" );

    if( strcmp( ptr, "Hello, world.\n" ) != 0 ) {
        printf( "malloc() - Failure\n" );
        failure++;
    } else printf( "malloc() - Success\n" );

    free( ptr );

    if( strcmp( ptr2, "Hello, again.\n" ) != 0 ) {
        printf( "malloc() (2) - Failure\n" );
        failure++;
    } else printf( "malloc() (2) - Success\n" );

    realloc( ptr2, 20 );

    strcat( ptr2, "Yup!\n" );

    if( strcmp( ptr2, "Hello, again.\nYup!\n" ) != 0 ) {
        printf( "realloc() - Failure\n" );
        failure++;
    } else printf( "realloc() - Success\n" );
    
    free( ptr2 );

    if( _fstrcmp( fptr, "Hello, world.\n" ) != 0 ) {
        printf( "_fmalloc() - Failure\n" );
        failure++;
    } else printf( "_fmalloc() - Success\n" );

    _ffree( fptr );

    if( _fstrcmp( fptr2, "Hello, again.\n" ) != 0 ) {
        printf( "_fmalloc() (2) - Failure\n" );
        failure++;
    } else printf( "_fmalloc() (2) - Success\n" );

    _frealloc( fptr2, 20 );

    _fstrcat( fptr2, "Yup!\n" );

    if( _fstrcmp( fptr2, "Hello, again.\nYup!\n" ) != 0 ) {
        printf( "_frealloc() - Failure\n" );
        failure++;
    } else printf( "_frealloc() - Success\n" );

    return( failure );
}

