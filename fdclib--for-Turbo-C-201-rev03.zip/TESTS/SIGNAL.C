#include <stdio.h>
#include <signal.h>

extern void __cleanup( void ); 
/* Must call this manually until startup code is available */

void genint23( void );
#pragma aux genint23 = "int 0x23";

unsigned sigintcalled = 0;

void siginthandle( int sig )
{
    printf( "signal() - Success\n" );
    sigintcalled = 1;
}

int main( int argc, char **argv )
{
    int failure = 0;

    signal( SIGINT, siginthandle );

    genint23();

    if( sigintcalled == 0 ) {
        printf( "signal() - Failure\n" );
        failure++;
    }

    return( failure );
}

