#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>

int teststdarg( int dummy, ... )
{
    va_list args = __va_ptr( dummy );

    return( strcmp( va_arg( args, char * ), "STDARG.H" ) );
}

int main( int argc, char **argv )
{
    if( teststdarg( 0, "STDARG.H" ) != 0 ) {
        printf( "va_arg() - Failure\n" );

        return( EXIT_FAILURE );
    }
    printf( "va_arg() - Success\n" );

    return( EXIT_SUCCESS );
}

