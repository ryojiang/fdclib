#include <dos.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <dir.h>
#include <fcntl.h>

int main( int argc, char **argv )
{
    int failure = 0, i = 1;
    unsigned seg, handle, date, time, nread, attrs;
    struct country ctest;
    struct ftime timetest;
    struct ffblk findblk;
    struct dosdate_t ddate;
    struct dostime_t dtime;
    struct diskfree_t dskfree;
    void interrupt far ( *oldvect )();
    char readbuf[ 15 ];

    printf( "Dos.lib\n" );

    printf( "%i - ", i++ );
    if( allocmem( 16, &seg ) != -1 ) {
        printf( "Failure\n" );
        failure++;
    } else {
        if( freemem( seg ) != 0 ) {
            printf( "Failure\n" );
            failure++;
        } else printf( "Success\n" );
    }

    printf( "%i - ", i++ );

    if( ( bdos( 0x19, 0, 0 ) & 0xFF ) != getdisk() ) {
        printf( "Failure\n" );
        failure++;
    } else printf( "Success\n" );

    printf( "%i - ", i++ );
    if( bdosptr( 0x3B, ".", 0 ) == -1 ) {/* CD . */
        printf( "Failure\n" );
        failure++;
    } else printf( "Success\n" );

    printf( "%i - ", i++ );
    if( country( 0, &ctest ) == NULL ) {
        printf( "Failure\n" );
        failure++;
    } else printf( "Success\n" );

    printf( "%i - ", i++ );
    if( _dos_creatnew( "TEST.TXT", _A_NORMAL, &handle ) ) {
        printf( "Failure\n" );
        failure++;
    } else printf( "Success\n" );

    printf( "%i - ", i++ );
    if( _dos_close( handle ) ) {
        printf( "Failure\n" );
        failure++;
    } else printf( "Success\n" );

    printf( "%i - ", i++ );
    if( _dos_creat( "TEST.TXT", _A_NORMAL, &handle ) ) {
        printf( "Failure\n" );
        failure++;
    } else printf( "Success\n" );

    printf( "%i - ", i++ );
    if( _dos_getftime( handle, &date, &time ) ) {
        printf( "Failure\n" );
        failure++;
    } else printf( "Success\n" );

    printf( "%i - ", i++ );
    if( _dos_setftime( handle, date, time ) ) {
        printf( "Failure\n" );
        failure++;
    } else printf( "Success\n" );

    printf( "%i - ", i++ );
    if( getftime( handle, &timetest ) == -1 ) {
        printf( "Failure\n" );
        failure++;
    } else printf( "Success\n" );

    printf( "%i - ", i++ );
    if( setftime( handle, &timetest ) == -1 ) {
        printf( "Failure\n" );
        failure++;
    } else printf( "Success\n" );

    printf( "%i - ", i++ );
    if( _dos_write( handle, "Hello, world.\n", 14, &nread ) ) {
        printf( "Failure\n" );
        failure++;
    } else printf( "Success\n" );

    printf( "%i - ", i++ );
    if( _dos_close( handle ) ) {
        printf( "Failure\n" );
        failure++;
    } else printf( "Success\n" );

    printf( "%i - ", i++ );
    if( _dos_open( "TEST.TXT", O_RDONLY, &handle ) ) {
        printf( "Failure\n" );
        failure++;
    } else printf( "Success\n" );

    printf( "%i - ", i++ );
    if( _dos_read( handle, readbuf, 14, &nread ) ||
        strncmp( readbuf, "Hello, world.\n", 14 ) != 0 ) {
        printf( "Failure\n" );
        failure++;
    } else printf( "Success\n" );

    printf( "%i - ", i++ );
    _dos_close( handle );

    if( _dos_findfirst( "*.*", _A_NORMAL, &findblk ) ) {
        printf( "Failure\n" );
        failure++;
    } else printf( "Success\n" );

    printf( "%i - ", i++ );
    if( _dos_findnext( &findblk ) ) {
        printf( "Failure\n" );
        failure++;
    } else printf( "Success\n" );

    printf( "%i - ", i++ );
    if( _dos_findclose( &findblk ) ) {
        printf( "Failure\n" );
        failure++;
    } else printf( "Success\n" );

    printf( "%i - ", i++ );
    if( _dos_getdiskfree( 0, &dskfree ) ) {
        printf( "Failure\n" );
        failure++;
    } else printf( "Success\n" );

    printf( "%i - ", i++ );
    if( _dos_getfileattr( "TEST.TXT", &attrs ) || attrs != _A_ARCH ) {
        printf( "Failure\n" );
        failure++;
    } else printf( "Success\n" );

    printf( "%i - ", i++ );
    if( _dos_setfileattr( "TEST.TXT", _A_RDONLY ) ) {
        printf( "Failure\n" );
        failure++;
    } else printf( "Success\n" );

    _dos_setfileattr( "TEST.TXT", _A_NORMAL );

    oldvect = _dos_getvect( 0x23 );

    _dos_setvect( 0x23, ( void interrupt far ( * )() )main );

    printf( "%i - ", i++ );
    if( _dos_getvect( 0x23 ) != ( void interrupt far ( * )() )main ) {
        printf( "Failure\n" );
        failure++;
    } else printf( "Success\n" );

    _dos_setvect( 0x23, oldvect );

    printf( "%i - ", i++ );
    if( getpsp() != _psp ) {
        printf( "Failure\n" );
        failure++;
    } else printf( "Success\n" );

    printf( "%i - ", i++ );
    if( unlink( "TEST.TXT" ) == -1 ) {
        printf( "Failure\n" );
        failure++;
    } else printf( "Success\n" );

    return( failure );
}

