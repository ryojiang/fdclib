#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int main( int argc, char **argv )
{
    int failure = 0;
    char cgetstest[ 6 ];
    char screenbuf[ 2000 ];
    char *passbuf;
    int curx, cury;

    printf( "Conio.lib\n" );

    if( ungetch( '\n' ) == -1 ||
        ungetch( '\r' ) == -1 ||
        ungetch( 'k' ) == -1 ) {
        printf( "Failure\n" );
        failure++;
    } else printf( "Success\n" );

    cgetstest[ 0 ] = 3;

    cgets( cgetstest );

    if( strcmp( &cgetstest[ 2 ], "k" ) != 0 ) {
        printf( "Failure\n" );
        failure++;
    } else printf( "Success\n" );

    if( putch( 'S' ) == -1 ) {
        printf( "Failure\n" );
        failure++;
    } else printf( "Success\n" );
    
    if( gettext( 0, wherey(), 0, wherey(), cgetstest ) == 0 ||
        cgetstest[ 0 ] != 'S' ) {
        printf( "Failure\n" );
        failure++;
    } else printf( "Success\n" );

    clreol();

    if( gettext( 1, wherey(), 1, wherey(), cgetstest ) == 0 ||
        cgetstest[ 0 ] == 'S' ) {
        printf( "Failure\n" );
        failure++;
    } else printf( "Success\n" );

    if( gettext( 1, 1, 80, 25, screenbuf ) == 0 ) {
        printf( "Failure\n" );
        failure++;
    } else printf( "Success\n" );

    clrscr();

    if( gettext( 1, wherey() - 1, 1, wherey() - 1, cgetstest ) == 0 ||
        !isblank( cgetstest[ 0 ] ) ) {
        printf( "Failure\n" );
        failure++;
    } else {
        if( puttext( 1, 1, 80, 25, screenbuf ) == 0 ) {
            printf( "Failure\n" );
            failure++;
        } else printf( "Success\n" );
        printf( "Success\n" );
    }

    if( cprintf( "Success\r\n" ) < 9 ) {
        printf( "Failure\n" );
        failure++;
    }

    if( cputs( "Success\r\n" ) != '\n' ) {
        printf( "Failure\n" );
        failure++;
    }

    /* Add cscanf here */

    if( ungetch( 'S' ) == -1 ) {
        printf( "Failure\n" );
        failure++;
    } else printf( "Success\n" );

    if( getch() != 'S' ) {
        printf( "Failure\n" );
        failure++;
    } else printf( "Success\n" );

    if( ungetch( 'S' ) == -1 ) {
        printf( "Failure\n" );
        failure++;
    } else printf( "Success\n" );

    if( getche() != 'S' ) {
        printf( "Failure\n" );
        failure++;
    } else printf( "uccess\n" );

    if( ungetch( '1' ) == -1 ||
        ungetch( '2' ) == -1 ||
        ungetch( '3' ) == -1 ||
        ungetch( '4' ) == -1 ||
        ungetch( '5' ) == -1 ||
        ungetch( '6' ) == -1 ||
        ungetch( '7' ) == -1 ||
        ungetch( '8' ) == -1 ) {
        printf( "Failure\n" );
        failure++;
    } else {
        passbuf = getpass( "" );
        if( strcmp( passbuf, "12345678" ) != 0 ) {
            printf( "\rFailure\n" );
            failure++;
        } else printf( "\rSuccess\n" );
    }

    curx = wherex();
    cury = wherey();

    gotoxy( curx + 1, cury + 1 );

    if( wherex() != curx + 1 || wherey() != cury + 1 ) {
        printf( "Failure\n" );
        failure++;
    } else {
        gotoxy( curx, cury );
        printf( "Success\n" );
    }

    ungetch( 'A' );

    if( !kbhit() ) {
        printf( "Failure\n" );
        failure++;
    } else {
        getch();
        printf( "Success\n" );
    }

    if( putch( 'S' ) == -1 ) {
        printf( "Failure\n" );
        failure++;
    } else {
        printf( "uccess\n" );
    }

    return( failure );
}

