#include <ctype.h>
#include <stdlib.h>
#include <stdio.h>

int main( int argc, char **argv )
{
    int failure = 0;

    printf( "Ctype.lib\n" );
    if( isalnum( '@' ) ) {
        printf( "1 - Failure\n" );
        failure++;
    } else printf( "1 - Success\n" );
    if( !isalnum( 'I' ) ) {
        printf( "2 - Failure\n" );
        failure++;
    } else printf( "2 - Success\n" );
    if( isalpha( '3' ) ) {
        printf( "3 - Failure\n" );
        failure++;
    } else printf( "3 - Success\n" );
    if( !isalpha( 'A' ) ) {
        printf( "4 - Failure\n" );
        failure++;
    } else printf( "4 - Success\n" );
    if( isascii( 255 ) ) {
        printf( "5 - Failure\n" );
        failure++;
    } else printf( "5 - Success\n" );
    if( !isascii( toascii( 255 ) ) ) {
        printf( "6 - Failure\n" );
        failure++;
    } else printf( "6 - Success\n" );
    if( isblank( '_' ) ) {
        printf( "7 - Failure\n" );
        failure++;
    } else printf( "7 - Success\n" );
    if( !isblank( '\t' ) ) {
        printf( "8 - Failure\n" );
        failure++;
    } else printf( "8 - Success\n" );
    if( iscntrl( '@' ) ) {
        printf( "9 - Failure\n" );
        failure++;
    } else printf( "9 - Success\n" );
    if( !iscntrl( 127 ) ) { /* Ctrl-BS */
        printf( "10 - Failure\n" );
        failure++;
    } else printf( "10 - Success\n" );
    if( isdigit( 'a' ) ) {
        printf( "11 - Failure\n" );
        failure++;
    } else printf( "11 - Success\n" );
    if( !isdigit( '9' ) ) {
        printf( "12 - Failure\n" );
        failure++;
    } else printf( "12 - Success\n" );
    if( isgraph( 0x1B ) ) { /* ESC */
        printf( "13 - Failure\n" );
        failure++;
    } else printf( "13 - Success\n" );
    if( !isgraph( ']' ) ) {
        printf( "14 - Failure\n" );
        failure++;
    } else printf( "14 - Success\n" );
    if( islower( 'A' ) ) {
        printf( "15 - Failure\n" );
        failure++;
    } else printf( "15 - Success\n" );
    if( !islower( 'a' ) ) {
        printf( "16 - Failure\n" );
        failure++;
    } else printf( "16 - Success\n" );
    if( isprint( 0x1B ) ) {
        printf( "17 - Failure\n" );
        failure++;
    } else printf( "17 - Success\n" );
    if( !isprint( '=' ) ) {
        printf( "18 - Failure\n" );
        failure++;
    } else printf( "18 - Success\n" );
    if( ispunct( '9' ) ) {
        printf( "19 - Failure\n" );
        failure++;
    } else printf( "19 - Success\n" );
    if( !ispunct( ',' ) ) {
        printf( "20 - Failure\n" );
        failure++;
    } else printf( "20 - Success\n" );
    if( isspace( '@' ) ) {
        printf( "21 - Failure\n" );
        failure++;
    } else printf( "21 - Success\n" );
    if( !isspace( ' ' ) ) {
        printf( "22 - Failure\n" );
        failure++;
    } else printf( "22 - Success\n" );
    if( isupper( 'a' ) ) {
        printf( "23 - Failure\n" );
        failure++;
    } else printf( "23 - Success\n" );
    if( !isupper( 'A' ) ) {
        printf( "24 - Failure\n" );
        failure++;
    } else printf( "24 - Success\n" );
    if( isxdigit( 'G' ) ) {
        printf( "25 - Failure\n" );
        failure++;
    } else printf( "25 - Success\n" );
    if( !isxdigit( 'F' ) ) {
        printf( "26 - Failure\n" );
        failure++;
    } else printf( "26 - Success\n" );
    if( tolower( 'A' ) != 'a' ) {
        printf( "27 - Failure\n" );
        failure++;
    } else printf( "27 - Success\n" );
    if( toupper( 'f' ) != 'F' ) {
        printf( "28 - Failure\n" );
        failure++;
    } else printf( "28 - Success\n" );
    if( _tolower( 'A' ) != 'a' ) {
        printf( "29 - Failure\n" );
        failure++;
    } else printf( "29 - Success\n" );
    if( _tolower( 'a' ) == 'a' ) {
        printf( "30 - Failure\n" );
        failure++;
    } else printf( "30 - Success\n" );
    if( _toupper( 'a' ) != 'A' ) {
        printf( "31 - Failure\n" );
        failure++;
    } else printf( "31 - Success\n" );
    if( _toupper( 'A' ) == 'A' ) {
        printf( "32 - Failure\n" );
        failure++;
    } else printf( "32 - Success\n" );

    return( failure );
}

