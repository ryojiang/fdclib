#include <malloc.h>
#include <string.h>

void far *_fcalloc( size_t items, size_t size )
{
    void far *ptr = _fmalloc( items * size );

    if( ptr == NULL ) return( NULL );

    _fmemset( ptr, 0, items * size );

    return( ptr );
}
