#include <dos.h>
#include <malloc.h>

void far *_fmalloc( size_t bytes )
{
    unsigned segm;

    if( _dos_allocmem( bytes, &segm ) != 0 ) return( NULL );

    return( MK_FP( segm, 0 ) );
}

void _ffree( void far *buf )
{
    _dos_freemem( FP_SEG( buf ) );
}

