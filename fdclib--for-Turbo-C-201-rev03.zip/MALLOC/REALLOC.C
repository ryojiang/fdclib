#include <malloc.h>
#include <string.h>

void *realloc( void *ptr, size_t size )
{
    char *newptr;

    newptr = malloc( size );
    if( newptr == NULL ) return( NULL );
    if( ptr != NULL ) {
        memcpy( newptr, ptr, size );
    }
    free( ptr );
    ptr = newptr;

    return( newptr );
}

