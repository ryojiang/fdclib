#include <malloc.h>
#include <string.h>

void *calloc( size_t items, size_t size )
{
    void *ptr = malloc( items * size );

    if( ptr == NULL ) return( NULL );

    memset( ptr, 0, items * size );

    return( ptr );
}
