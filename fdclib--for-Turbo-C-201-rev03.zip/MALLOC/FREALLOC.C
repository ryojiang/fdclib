#include <malloc.h>
#include <string.h>

void far *_frealloc( void far *ptr, size_t size )
{
    char far *newptr;

    newptr = _fmalloc( size );
    if( newptr == NULL ) return( NULL );
    if( ptr != NULL ) {
        _fmemcpy( newptr, ptr, size );
    }
    _ffree( ptr );
    ptr = newptr;

    return( newptr );
}

