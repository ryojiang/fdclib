int tolower( int ch )
{
    if( ch >= 'A' && ch <= 'Z' ) {
        ch -= 'A';
        ch += 'a';
    }

    return( ch );
}
