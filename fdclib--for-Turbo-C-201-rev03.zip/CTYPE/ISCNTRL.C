int iscntrl( int ch )
{
    return( ( ch >= 0 && ch <= 0x1F ) || ch == 0x7F );
}
