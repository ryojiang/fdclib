#include <ctype.h>

int isblank( int ch )
{
    return( ch == ' ' || ch == '\t' );
}

