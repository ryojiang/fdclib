int toupper( int ch )
{
    if( ch >= 'a' && ch <= 'z' ) {
        ch -= 'a';
        ch += 'A';
    }

    return( ch );
}
