int isupper( int ch )
{
    return( ( ch >= 'A' && ch <= 'Z' ) );
}
