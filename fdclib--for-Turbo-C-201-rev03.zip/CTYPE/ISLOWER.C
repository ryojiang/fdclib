int islower( int ch )
{
    return( ( ch >= 'a' && ch <= 'z' ) );
}
