int isascii( int ch )
{
    return( ( ch >= 0 && ch <= 127 ) );
}
