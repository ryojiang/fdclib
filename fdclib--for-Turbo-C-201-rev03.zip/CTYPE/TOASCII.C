int toascii( int ch )
{
    return( ch & 0177 );
}
