int isdigit( int ch )
{
    return( ( ch >= '0' && ch <= '9' ) );
}
