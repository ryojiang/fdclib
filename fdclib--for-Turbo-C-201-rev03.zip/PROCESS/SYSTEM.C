#include <dos.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

int __errorlevel;

int system( const char *command )
{
    char *comspec = getenv( "COMSPEC" );
    char cmdline[ _POSIX_ARG_MAX ];

    if( command == NULL || comspec == NULL ) return( -1 );

    strcpy( cmdline, "/c " );
    strncpy( &cmdline[ 3 ], command, _POSIX_ARG_MAX - 4 );

    if( ( __errorlevel = _exec( comspec, cmdline ) ) == -1 ) return( -1 );

    return( 0 );
}

