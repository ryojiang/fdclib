#include <process.h>

int execvpe( const char *path, char **argv, char **envp )
{
    return( spawnvpe( P_OVERLAY, path, argv, envp ) );
}

