#include <process.h>
#include <stdlib.h>
#include <io.h>
#include <dos.h>
#include <string.h>

int _bgetcmd( char *cmdline, int len )
{
    char far *ptr = getenv( "CMDLINE" );
    char *c = cmdline;
    int length;

    if( ptr != NULL ) {
        length = _fstrlen( ptr );
        _fstrncpy( cmdline, ptr, len );

        return( length );
    }

    ptr = MK_FP( _psp, 0x81 );
    length = 0;
    len--;

    while( *ptr != '\r' ) {
        if( len ) {
            *c = *ptr;
            len--;
            c++;
        }
        length++;
        ptr++;
    }
    *c = '\0';

    return( length );
}

