#include <process.h>

int execvp( const char *path, char **argv )
{
    return( spawnvp( P_OVERLAY, path, argv ) );
}

