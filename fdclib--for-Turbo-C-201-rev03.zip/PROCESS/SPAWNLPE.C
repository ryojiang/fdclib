#include <stdarg.h>
#include <process.h>
#include <string.h>

int spawnlpe( int mode, char *path, ... )
{
    char **envp;
    va_list args;

    va_start( args, path );

    while( va_arg( args, char * ) != NULL );
    envp = va_arg( args, char ** );

    va_start( args, path );

    return( spawnvpe( mode, path, ( char ** )args, envp ) );
}

