#include <stdarg.h>
#include <string.h>
#include <process.h>

int execle( const char *path, ... )
{
    char **envp;
    va_list args;

    va_start( args, path );

    while( ( char * )va_arg( args, char * ) != NULL );
    envp = ( char ** )va_arg( args, char ** );

    va_start( args, path );
    
    return( spawnve( P_OVERLAY, path, ( char ** )args, envp ) );
}

