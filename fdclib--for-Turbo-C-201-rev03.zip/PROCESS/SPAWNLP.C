#include <stdarg.h>
#include <process.h>

int spawnlp( int mode, char *path, ... )
{
    va_list args;

    va_start( args, path );

    return( spawnvp( mode, path, ( char ** )args ) );
}
