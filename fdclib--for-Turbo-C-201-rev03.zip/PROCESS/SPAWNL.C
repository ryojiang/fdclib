#include <stdarg.h>
#include <process.h>

int spawnl( int mode, char *path, ... )
{
    va_list args;

    va_start( args, path );

    return( spawnv( mode, path, ( char ** )args ) );
}

