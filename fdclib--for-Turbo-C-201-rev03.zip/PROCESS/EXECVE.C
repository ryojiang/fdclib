#include <process.h>

int execve( const char *path, char **argv, char **envp )
{
    return( spawnve( P_OVERLAY, path, argv, envp ) );
}

