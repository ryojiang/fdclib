#include <process.h>
#include <stdlib.h>
#include <io.h>
#include <dos.h>
#include <string.h>

char *getcmd( char *cmdline )
{
    char far *ptr = getenv( "CMDLINE" );
    char *c = cmdline;

    if( ptr != NULL ) {
        _fstrcpy( cmdline, ptr );

        return( cmdline );
    }

    ptr = MK_FP( _psp, 0x81 );

    while( *ptr != '\r' ) {
        *c = *ptr;
        c++;
        ptr++;
    }
    *c = '\0';

    return( cmdline );
}

