#include <stdarg.h>
#include <process.h>

int execl( const char *path, ... )
{
    va_list args;

    va_start( args, path );

    return( spawnv( P_OVERLAY, path, ( char ** )args ) );
}

