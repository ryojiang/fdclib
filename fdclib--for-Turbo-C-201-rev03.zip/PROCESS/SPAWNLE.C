#include <stdarg.h>
#include <process.h>
#include <stddef.h>

int spawnle( int mode, char *path, ... )
{
    char **envp;
    va_list args;

    va_start( args, path );

    while( va_arg( args, char * ) != NULL );
    envp = va_arg( args, char ** );

    va_start( args, path );

    return( spawnve( mode, path, ( char ** )args, envp ) );
}
