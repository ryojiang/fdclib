#include <stdarg.h>
#include <process.h>

int execlp( const char *path, ... )
{
    va_list args;

    va_start( args, path );

    return( spawnvp( P_OVERLAY, path, ( char ** )args ) );
}

