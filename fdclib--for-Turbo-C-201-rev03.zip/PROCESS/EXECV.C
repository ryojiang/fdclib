#include <process.h>

int execv( const char *path, char **argv )
{
    return( spawnv( P_OVERLAY, path, argv ) );
}

