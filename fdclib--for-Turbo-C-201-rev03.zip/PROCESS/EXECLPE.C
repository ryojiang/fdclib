#include <stdarg.h>
#include <string.h>
#include <process.h>

int execlpe( const char *path, ... )
{
    char **envp;
    va_list args;

    va_start( args, path );

    while( va_arg( args, char * ) != NULL );
    envp = va_arg( args, char ** );

    va_start( args, path );

    return( spawnvpe( P_OVERLAY, path, ( char ** )args, envp ) );
}

