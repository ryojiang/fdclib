#include <string.h>

char far *_fstrcpy( char far *dest, const char far *source )
{
    char far *d = dest;
    const char far *s = source;

    while( *s ) {
        *d = *s;
        d++;
        s++;
    }
    *d = '\0';

    return( dest );
}
