#include <string.h>

char *strncat( char *string, const char *append, size_t len )
{
#if 0
    char *s = string;
    const char *a = append;

    while( *s ) *s++;   /* Set to the end of the string */
    while( *a && len ) {
        *s = *a;
        *s++;
        *a++;
        len--;
    }
    *s = '\0';

    return( string );
#else
    return( strncpy( string + strlen( string ), append, len ) );
#endif
}

