#include <string.h>
#include <errno.h>

char *_strerror( const char *s )
{
    static char errstring[ 256 ];

    if( s == NULL ) return( strerror( errno ) );
    strncpy( errstring, s, 94 );
    strcat( errstring, ": " );
    strcat( errstring, strerror( errno ) );
    strcat( errstring, "\n" );

    return( errstring );
}
