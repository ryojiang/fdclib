#include <string.h>

char far *_fstrset( char far *string, int ch )
{
    char far *s = string;

    while( *s ) {
        *s = ch;
        s++;
    }
    
    return( string );
}
