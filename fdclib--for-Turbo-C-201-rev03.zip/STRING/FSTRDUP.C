#include <malloc.h>
#include <string.h>

char far *_fstrdup( const char far *string )
{
    char far *s = _fmalloc( _fstrlen( string ) + 1 );

    _fstrcpy( s, string );

    return( s );
}
