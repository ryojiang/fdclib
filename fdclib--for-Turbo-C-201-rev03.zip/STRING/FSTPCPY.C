#include <string.h>

char far *_fstpcpy( char far *dest, const char far *source )
{
    char far *d = dest;
    const char far *s = source;

    while( ( *d++ = *s++ ) );
    return( d - 1 );
}
