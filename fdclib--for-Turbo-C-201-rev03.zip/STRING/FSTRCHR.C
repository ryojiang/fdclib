#include <string.h>

char far *_fstrchr( const char far *s, int c )
{
    return( _fmemchr( s, c, _fstrlen( s ) ) );
}
