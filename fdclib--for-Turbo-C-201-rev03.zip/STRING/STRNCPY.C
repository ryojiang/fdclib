#include <string.h>

char *strncpy( char *dest, const char *source, size_t len )
{
    char *d = dest;
    const char *s = source;

    while( *s && len ) {
        *d = *s;
        d++;
        s++;
        len--;
    }
    *d = '\0';

    return( dest );
}

