#include <string.h>
#include <sys/types.h>

size_t _fstrlcpy( char far *dst, const char far *src, size_t size )
{
    size_t length, copy;

    length = _fstrlen( src );
    if( size > 0 ) {
        copy = ( length >= size ) ? size - 1 : length;
        _fmemcpy( dst, src, copy );
        dst[ copy ] = '\0';
    }
    
    return( length );
}

