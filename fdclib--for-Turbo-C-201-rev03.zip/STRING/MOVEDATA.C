#include <string.h>
#include <dos.h>

void movedata( unsigned sourceseg,
               unsigned sourceoff,
               unsigned destseg,
               unsigned destoff,
               size_t len )
{
    _fmemcpy( MK_FP( sourceseg, sourceoff ), MK_FP( destseg, destoff ), len );
}
