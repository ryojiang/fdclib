#include <string.h>

char *strset( char *string, int ch )
{
    char *s = string;

    while( *s ) {
        *s = ch;
        s++;
    }
    
    return( string );
}
