#include <string.h>
#include <ctype.h>

int memicmp( const void *m1, const void *m2, size_t len )
{
    const char *s1 = m1, *s2 = m2 ;
    register int ch;

    while( len ) {
        if( ( ch = ( toupper( *s1 ) - toupper( *s2 ) ) ) ) return( ch );
        s1++;
        s2++;
        len--;
    }
    return( 0 );
}
