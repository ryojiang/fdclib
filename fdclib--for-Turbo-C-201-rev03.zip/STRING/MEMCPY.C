#include <string.h>

void *memcpy( void *dest, const void *source, size_t len )
{
    char *d = dest;
    const char *s = source;

    while( len ) {
        *d = *s;
        d++;
        s++;
        len--;
    }
    return( dest );
}
