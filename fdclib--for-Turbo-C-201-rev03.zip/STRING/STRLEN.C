#include <string.h>

size_t strlen( const char *string )
{
    const char *s = string;
    int len = 0;

    while( *s ) {
        s++;
        len++;
    }

    return( len );
}
