#include <string.h>

char *strcat( char *string, const char *append )
{
#if 0
    char *s = string + strlen( string ); /* Set to the end of the string */
    const char *a = append;

    while( *a ) {
        *s = *a;
        s++;
        a++;
    }
    *s = '\0';

    return( string );
#else
    return( strcpy( string + strlen( string ), append ) );
#endif
}
