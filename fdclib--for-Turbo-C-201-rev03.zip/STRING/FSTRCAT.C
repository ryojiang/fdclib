#include <string.h>

char far *_fstrcat( char far *string, const char far *append )
{
#if 0
    char far *s = string + _fstrlen( string ); /* Set to end of string */
    const char far *a = append;

    while( *a ) {
        *s = *a;
        s++;
        a++;
    }
    *s = '\0';

    return( string );
#else
    return( _fstrcpy( string + _fstrlen( string ), append ) );
#endif
}
