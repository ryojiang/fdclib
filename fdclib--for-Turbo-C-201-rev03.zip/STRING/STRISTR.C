#include <string.h>

char *stristr( const char *string, const char *pattern )
{
    const char *s = string;

    while( *s ) {
        if( strncmpi( s, pattern, strlen( pattern ) ) == 0 )
            return( ( char * )s );
        s++;
    }
    return( NULL );
}
