#include <string.h>

char far *_fstrnset( char far *string, int ch, size_t len )
{
    char far *s = string;

    while( *s && len ) {
        *s = ch;
        s++;
        len--;
    }
    
    return( string );
}
