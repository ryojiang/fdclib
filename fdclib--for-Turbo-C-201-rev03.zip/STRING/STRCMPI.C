#include <string.h>

int strcmpi( const char *s1, const char *s2 )
{
    register int len = strlen( s1 );
    register int len2 = strlen( s2 );

    return( memicmp( s1, s2, len > len2 ? len : len2  ) );
}
