#include <string.h>

char *strcpy( char *dest, const char *source )
{
    char *d = dest;
    const char *s = source;

    while( *s ) {
        *d = *s;
        d++;
        s++;
    }
    *d = '\0';

    return( dest );
}
