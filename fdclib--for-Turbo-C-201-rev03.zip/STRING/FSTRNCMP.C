#include <string.h>

int _fstrncmp( const char far *s1, const char far *s2, size_t len )
{
    register int amount = ( len > _fstrlen( s1 ) ) ? _fstrlen( s1 ) : len;
    return( _fmemcmp( s1, s2, amount ) );
}
