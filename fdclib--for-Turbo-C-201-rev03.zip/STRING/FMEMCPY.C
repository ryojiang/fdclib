#include <string.h>

void far *_fmemcpy( void far *dest, const void far *source, size_t len )
{
    char far *d = dest;
    const char far *s = source;

    while( len ) {
        *d = *s;
        d++;
        s++;
        len--;
    }
    return( dest );
}
