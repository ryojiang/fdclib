#include <string.h>

char *strrstr( const char *string, const char *pattern )
{
    const char *s = string + strlen( string ) - 1;

    while( *s-- ) {
        if( strncmp( s, pattern, strlen( pattern ) ) == 0 )
            return( ( char * )s );
    }

    return( NULL );
}
