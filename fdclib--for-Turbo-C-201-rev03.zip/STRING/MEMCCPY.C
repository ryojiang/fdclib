#include <string.h>

void *memccpy( void *dest, const void *source, int ch, size_t len )
{
    char *d = dest;
    const char *s = source;

    while( len ) {
        *d = *s;
        d++;
        if( *s == ch ) return( dest );
        s++;
        len--;
    }

    return( NULL );
}
