#include <stddef.h>
#include <string.h>

void *memrev( void *buf, size_t count )
{
    char *r, *b = buf;

    for( r = b + count - 1; b < r; b++, r-- ) {
        *b ^= *r;
        *r ^= *b;
        *b ^= *r;
    }

    return( buf );
}

