#include <string.h>

int strncmp( const char *s1, const char *s2, size_t len )
{
    register int amount = ( len > strlen( s1 ) ) ? strlen( s1 ) : len;
    return( memcmp( s1, s2, amount ) );
}
