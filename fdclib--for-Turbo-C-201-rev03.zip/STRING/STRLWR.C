#include <ctype.h>

char *strlwr( char *string )
{
    char *s = string;

    while( *s ) {
        *s = tolower( *s );
        s++;
    }

    return( string );
}
