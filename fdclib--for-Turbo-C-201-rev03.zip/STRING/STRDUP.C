#include <malloc.h>
#include <string.h>

char *strdup( const char *string )
{
    char *s = malloc( strlen( string ) + 1 );

    strcpy( s, string );

    return( s );
}
