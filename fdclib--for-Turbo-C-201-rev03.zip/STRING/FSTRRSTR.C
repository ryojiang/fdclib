#include <string.h>

char far *_fstrrstr( const char far *string, const char far *pattern )
{
    const char far *s = string + _fstrlen( string ) - 1;

    while( *s-- ) {
        if( _fstrncmp( s, pattern, _fstrlen( pattern ) ) == 0 )
            return( ( char far * )s );
    }

    return( NULL );
}
