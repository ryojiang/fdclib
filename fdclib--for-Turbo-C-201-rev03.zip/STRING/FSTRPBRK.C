#include <string.h>

char far *_fstrpbrk( const char far *s, const char far *pattern )
{
    const char far *p = s;
    
    while( *p ) {
        const char far *p2 = pattern;
        
        while( *p2 ) {
            if( *p == *p2 ) return( ( char far * )p );
            p2++;
        }
        p++;
    }
    return( NULL );
}
