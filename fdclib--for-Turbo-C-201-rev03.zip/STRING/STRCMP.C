#include <string.h>

int strcmp( const char *s1, const char *s2 )
{
    register int len = strlen( s1 ), len2 = strlen( s2 );

    return( memcmp( s1, s2, len > len2 ? len : len2 ) );
}
