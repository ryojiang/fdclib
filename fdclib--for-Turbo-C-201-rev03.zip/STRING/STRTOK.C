#include <string.h>

char *strtok( char *delimited, const char *token )
{
    static char *last;

    if( delimited == NULL )
        delimited = last;
    if( delimited != NULL ) {
        delimited += strspn( delimited, token );
        if( *delimited != '\0' ) {
            char *e;

            e = delimited + strcspn( delimited, token );
            if( *e != '\0' )
                *e++ = '\0';
            last = e;
            return( delimited );
        }
    }
    return( NULL );
}
