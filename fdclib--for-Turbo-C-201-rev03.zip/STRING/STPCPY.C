#include <string.h>

char *stpcpy( char *dest, const char *source )
{
    char *d = dest;
    const char *s = source;

    while( ( *d++ = *s++ ) );
    return( d );
}
