#include <string.h>

size_t strxfrm( char *dest, const char *source, size_t n )
{
    char *d = dest;
    const char *s = source;
    size_t len = 0;

    while( *s ) {
        if( len < n )*d = *s;
        d++;
        s++;
        len++;
    }

    return( len );
}

