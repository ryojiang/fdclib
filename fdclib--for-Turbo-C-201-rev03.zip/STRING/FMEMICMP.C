#include <string.h>
#include <ctype.h>

int _fmemicmp( const void far *m1, const void far *m2, size_t len )
{
    const char far *s1 = m1, far *s2 = m2;
    register int ch;

    while( len ) {
        if( ( ch = ( toupper( *s1 ) - toupper( *s2 ) ) ) ) return( ch );
        s1++;
        s2++;
        len--;
    }
    return( 0 );
}
