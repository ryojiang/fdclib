#include <string.h>

size_t _fstrlen( const char far *string )
{
    const char far *s = string;
    int len = 0;

    while( *s ) {
        s++;
        len++;
    }

    return( len );
}
