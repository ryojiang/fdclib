#include <string.h>

int memcmp( const void *m1, const void *m2, size_t len )
{
    const char *s1 = m1, *s2 = m2;
    register int ch = ( m1 > m2 ) ? ( int )m1 : ( int )m2;

    while( len ) {
        if( *s1 != *s2 ) return( ch );
        s1++;
        s2++;
        len--;
    }
    return( 0 );
}

