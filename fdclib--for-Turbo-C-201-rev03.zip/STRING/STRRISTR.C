#include <string.h>

char *strristr( const char *string, const char *pattern )
{
    const char *s = string + strlen( string ) - 1;

    while( *s-- ) {
        if( strncmpi( s, pattern, strlen( pattern ) ) == 0 )
            return( ( char * )s );
    }

    return( NULL );
}
