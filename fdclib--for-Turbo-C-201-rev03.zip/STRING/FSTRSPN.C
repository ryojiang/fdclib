#include <string.h>

size_t _fstrspn( const char far *s1, const char far *s2 )
{
    unsigned n = 0;

    while( *s1 && _fstrchr( s2, *s1++ ) ) n++;
    return( n );
}
