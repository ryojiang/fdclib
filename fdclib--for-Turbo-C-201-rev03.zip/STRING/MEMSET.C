#include <string.h>

void *memset( void *mem, int ch, size_t len )
{
    char *m = mem;

    while( len ) {
        *m = ch;
        m++;
        len--;
    }

    return( mem );
}
