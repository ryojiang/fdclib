#include <string.h>

char far *_fstrncpy( char far *dest, const char far *source, size_t len )
{
    char far *d = dest;
    const char far *s = source;

    while( *s && len ) {
        *d = *s;
        d++;
        s++;
        len--;
    }
    *d = '\0';

    return( dest );
}

