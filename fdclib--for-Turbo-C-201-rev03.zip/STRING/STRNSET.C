#include <string.h>

char *strnset( char *string, int ch, size_t len )
{
    char *s = string;

    while( *s && len ) {
        *s = ch;
        s++;
        len--;
    }
    
    return( string );
}
