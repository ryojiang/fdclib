#include <string.h>

char *strrev( char *string )
{
    return( memrev( string, strlen( string ) ) );
}
