#include <string.h>

int _fstrcoll( const char far *s1, const char far *s2 )
{
    return( _fstrcmp( s1, s2 ) );
}

