#include <string.h>

void far *_fmemset( void far *mem, int ch, size_t len )
{
    char far *m = mem;

    while( len ) {
        *m = ch;
        m++;
        len--;
    }

    return( mem );
}
