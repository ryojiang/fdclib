#include <string.h>

char *_far2nearcpy( char *dest, const char far *source )
{
    char *d = dest;
    const char far *s = source;

    while( *s ) {
        *d = *s;
        d++;
        s++;
    }

    return( dest );
}
