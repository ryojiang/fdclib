#include <string.h>

char *strstr( const char *string, const char *pattern )
{
    const char *s = string;

    while( *s ) {
        if( strncmp( s, pattern, strlen( pattern ) ) == 0 )
            return( ( char * )s );
        s++;
    }
    return( NULL );
}
