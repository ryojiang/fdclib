#include <ctype.h>

char far *_fstrlwr( char far *string )
{
    char far *s = string;

    while( *s ) {
        *s = tolower( *s );
        s++;
    }

    return( string );
}
