#include <string.h>

char far *_fstrrev( char far *string )
{
    return( _fmemrev( string, _fstrlen( string ) ) );
}
