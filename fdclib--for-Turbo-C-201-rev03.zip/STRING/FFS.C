#include <strings.h>

int ffs( int value )
{
    register int bit;

    if( value == 0 ) return( 0 );
    for( bit = 1; !( value & 1 ); bit++ ) value >>= 1;

    return( bit );
}
