#include <string.h>
#include <ctype.h>

char *strupr( char *string )
{
    char *s = string;

    while( *s ) {
        *s = toupper( *s );
        s++;
    }

    return( string );
}
