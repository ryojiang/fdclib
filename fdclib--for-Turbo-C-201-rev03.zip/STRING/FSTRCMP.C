#include <string.h>

int _fstrcmp( const char far *s1, const char far *s2 )
{
    register int len = _fstrlen( s1 ), len2 = _fstrlen( s2 );

    return( _fmemcmp( s1, s2, len > len2 ? len : len2 ) );
}
