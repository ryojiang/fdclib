#include <string.h>

char far *_near2farcpy( char far *dest, const char *source )
{
    char far *d = dest;
    const char *s = source;

    while( *s ) {
        *d = *s;
        d++;
        s++;
    }

    return( dest );
}
