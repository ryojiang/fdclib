#include <string.h>

size_t _fstrxfrm( char far *dest, const char far *source, size_t n )
{
    char far *d = dest;
    const char far *s = source;
    size_t len = 0;

    while( *s ) {
        if( len < n )*d = *s;
        d++;
        s++;
        len++;
    }

    return( len );
}

