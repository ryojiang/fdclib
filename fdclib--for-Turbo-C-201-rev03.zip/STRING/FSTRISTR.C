#include <string.h>

char far *_fstristr( const char far *string, const char far *pattern )
{
    const char far *s = string;

    while( *s ) {
        if( _fstrncmpi( s, pattern, _fstrlen( pattern ) ) == 0 )
            return( ( char far * )s );
        s++;
    }
    return( NULL );
}
