#include <string.h>

char *strpbrk( const char *s, const char *pattern )
{
    const char *p = s;
    
    while( *p ) {
        const char *p2 = pattern;
        
        while( *p2 ) {
            if( *p == *p2 ) return( ( char * )p );
            p2++;
        }
        p++;
    }
    return( NULL );
}
