#include <string.h>

char far *_fstrrchr( const char far *string, int ch )
{
    const char far *s = string + _fstrlen( string ) - 1;

    while( *s-- ) {
        if( *s == ch ) return( ( char far * )s );
    }

    return( NULL );
}

