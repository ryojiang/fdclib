#include <string.h>

void *memchr( const void *mem, int ch, size_t len )
{
    const char *m = mem;

    while( len ) {
        if( *m == ch ) return( ( void * )m );
        m++;
        len--;
    }
    return( NULL );
}
