#include <stddef.h>
#include <string.h>

void far *_fmemrev( void far *buf, size_t count )
{
    char far *r, far *b = buf;

    for( r = b + count - 1; b < r; b++, r-- ) {
        *b ^= *r;
        *r ^= *b;
        *b ^= *r;
    }

    return( buf );
}

