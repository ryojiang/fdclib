#include <string.h>

char *strrchr( const char *string, int ch )
{
    const char *s = string + strlen( string ) - 1;

    while( *s-- ) {
        if( *s == ch ) return( ( char * )&*s );
    }

    return( NULL );
}

