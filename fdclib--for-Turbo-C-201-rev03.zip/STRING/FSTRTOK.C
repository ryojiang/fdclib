#include <string.h>

char far *_fstrtok( char far *delimited, const char far *token )
{
    static char far *last;

    if( delimited == NULL )
        delimited = last;
    if( delimited != NULL ) {
        delimited += _fstrspn( delimited, token );
        if( *delimited != '\0' ) {
            char far *e;

            e = delimited + _fstrcspn( delimited, token );
            if( *e != '\0' )
                *e++ = '\0';
            last = e;
            return( delimited );
        }
    }
    return( NULL );
}
