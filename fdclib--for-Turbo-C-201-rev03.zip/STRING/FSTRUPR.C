#include <string.h>
#include <ctype.h>

char far *_fstrupr( char far *string )
{
    char far *s = string;

    while( *s ) {
        *s = toupper( *s );
        s++;
    }

    return( string );
}
