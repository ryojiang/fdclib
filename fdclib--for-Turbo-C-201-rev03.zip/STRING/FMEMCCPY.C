#include <string.h>

void far *_fmemccpy( void far *dest,
                     const void far *source,
                     int ch,
                     size_t len )
{
    char far *d = dest;
    const char far *s = source;

    while( len ) {
        *d = *s;
        d++;
        if( *s == ch ) return( dest );
        s++;
        len--;
    }

    return( NULL );
}
