#include <string.h>

void far *_fmemchr( const void far *mem, int ch, size_t len )
{
    const char far *m = mem;

    while( len ) {
        if( *m == ch ) return( ( void * )m );
        m++;
        len--;
    }
    return( NULL );
}
