#include <string.h>

char far *_fstrncat( char far *string, const char far *append, size_t len )
{
#if 0
    char far *s = string;
    const char far *a = append;

    while( *s ) *s++;   /* Set to the end of the string */
    while( *a && len ) {
        *s = *a;
        *s++;
        *a++;
        len--;
    }
    *s = '\0';

    return( string );
#else
    return( _fstrncpy( string + _fstrlen( string ), append, len ) );
#endif
}

