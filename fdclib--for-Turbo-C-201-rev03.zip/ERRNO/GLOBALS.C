#include <errno.h>

unsigned errno, _doserrno;

unsigned *__get_errno_ptr( void ) { return( &errno ); }
unsigned *__get_doserrno_ptr( void ) { return( &_doserrno ); }

