#include <time.h>
#include <sys/timeb.h>

void ftime( struct timeb *buf )
{
    time_t curtime;

    buf->dstflag = daylight;
    buf->timezone = timezone;
    buf->time = time( &curtime );
    buf->millitm = ( ( clock() / 60 ) / 60 ) % 1000;
}
