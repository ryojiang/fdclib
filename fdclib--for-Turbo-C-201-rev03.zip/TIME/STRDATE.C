#include <time.h>
#include <dos.h>
#include <stdio.h>

char *_strdate( char *buf )
{
    time_t curtime;
    struct tm *curtm;

    time( &curtime );
    curtm = localtime( &curtime );

    sprintf( buf, "%02u:%02u:%02u",
             curtm->tm_mon,
             curtm->tm_mday,
             curtm->tm_year );

    return( buf );
}
