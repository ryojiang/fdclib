#include <time.h>
#include <dos.h>
#include <stdio.h>

char *_strtime( char *buf )
{
    time_t curtime;
    struct tm *curtm;

    time( &curtime );
    curtm = localtime( &curtime );

    sprintf( buf, "%02u:%02u:%02u",
             curtm->tm_hour,
             curtm->tm_min,
             curtm->tm_sec );

    return( buf );
}
