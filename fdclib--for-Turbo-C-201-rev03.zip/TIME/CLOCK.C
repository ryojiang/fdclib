#include <time.h>
#include <dos.h>

char far * __dogettk( void );
#pragma aux __dogettk = \
    "mov ah, 0x00"      \
    "int 0x1A"          \
    "or al, al"         \
    "jz skip"/*reset midnight flag*/\
    "mov ah, 0x01"      \
    "int 0x1A"          \
    "skip:"             \
    value [cx dx]       \
    modify [ax cx dx];

static clock_t __prevtime = 0;

clock_t clock( void )
{
    char far * timeblk = __dogettk();
    clock_t curtime = FP_OFF( timeblk ) + ( FP_SEG( timeblk ) * 65520L );
                                        /* ticks per hour */

    while( curtime < __prevtime ) curtime += 0x1800B0; /* ticks per day */

    __prevtime = curtime;

    return( curtime );
}
