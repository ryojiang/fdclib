#include <sys/times.h>
#include <time.h>

clock_t times( struct tms *buffer )
{
    return( ( buffer->tms_utime  =
              buffer->tms_stime  =
              buffer->tms_cutime =
              buffer->tms_cstime = clock() ) );
}

