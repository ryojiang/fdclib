#include <time.h>
#include <dos.h>
#include "internal.h"

time_t time( time_t *timer )
{
    time_t tt;
    struct dosdate_t dt;
    struct dostime_t tm;
    
    _dos_getdate( &dt );
    _dos_gettime( &tm );

    tt = __ymd_to_scalar( dt.year, dt.month, dt.day ) -
         __ymd_to_scalar( 1970, 1, 1 );
    tt = tt * 24 + tm.hour;
    tt = tt * 60 + tm.minute;
    tt = tt * 60 + tm.second;
    
    if( timer != NULL ) *timer = tt;
    
    return( tt );
}

