#include <time.h>
#include "internal.h"

long __ymd_to_scalar( unsigned yr, unsigned mo, unsigned day )
{
    long scalar;

    scalar = day + __months_to_days( mo );
    if( mo > 2 )                         /* adjust if past February */
        scalar -= __isleap( yr ) ? 1 : 2;
    yr--;
    scalar += __years_to_days( yr );
    return ( scalar );
}

