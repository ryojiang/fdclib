#include <time.h>

struct tm *gmtime( const time_t *timer )
{
    return( localtime( timer ) );
}
