#include <time.h>
#include <dos.h>

int stime( time_t *timer )
{
    struct date dt;
    struct time tm;

    unixtodos( *timer, &dt, &tm );
    setdate( &dt );
    settime( &tm );

    return( 0 );
}
