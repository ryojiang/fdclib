#include <time.h>

char *tzname[2] = { "GMT", "0" };
long timezone = 0L;
int daylight = 1;

int __isleap( unsigned yr )
{
    return( yr % 400 == 0 || ( yr % 4 == 0 && yr % 100 != 0 ) );
}

unsigned __months_to_days( unsigned month )
{
    return( ( month * 3057 - 3007 ) / 100 );
}

long __years_to_days( unsigned yr )
{
    return( yr * 365L + yr / 4 - yr / 100 + yr / 400 );
}

