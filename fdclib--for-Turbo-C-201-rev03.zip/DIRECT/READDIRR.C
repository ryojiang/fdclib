#include <dirent.h>
#include <dos.h>
#include <string.h>

int readdir_r( DIR * restrict dirp,
               struct dirent * restrict entry,
               struct dirent ** restrict result )
{
    if( dirp->d_first ) dirp->d_first = 0;
    else if( findnext( dirp ) ) {
        *result = NULL;

        return( 0 );
    }

    *result = entry = dirp;

    dirp->d_loc++;
    dirp->d_namlen = strlen( dirp->d_name );

    return( 0 );
}

