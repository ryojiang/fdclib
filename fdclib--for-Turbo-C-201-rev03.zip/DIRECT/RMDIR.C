#include <direct.h>
#include <errno.h>

int __dormdir( const char *path );
#pragma aux __dormdir = \
    "mov ah, 0x3A"      \
    "int 0x21"          \
    "sbb ax, ax"        \
    parm [dx]           \
    value [ax]          \
    modify [ax dx];

int rmdir( const char *path )
{
    if( __dormdir( __retsfn( path ) ) < 0 ) {
        errno = ENOENT;
        return( -1 );
    }

    return( 0 );
}
