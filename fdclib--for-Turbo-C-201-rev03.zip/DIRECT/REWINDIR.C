#include <dirent.h>
#include <dos.h>

void rewinddir( DIR *dirp )
{
    findclose( dirp );

    if( findfirst( dirp->d_fnamused, dirp, _A_HIDDEN|_A_SYSTEM|_A_SUBDIR ) )
        dirp->d_first = 0;
    else dirp->d_first = 1;

    dirp->d_loc = 0;
}
