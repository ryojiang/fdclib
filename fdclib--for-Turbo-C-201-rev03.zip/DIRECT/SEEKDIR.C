#include <dirent.h>
#include <dos.h>

void seekdir( DIR *dirp, long loc )
{
/*    loc--;    */

    rewinddir( dirp );
    while( telldir( dirp ) < loc && dirp != NULL ) readdir( dirp );
    if( dirp->d_loc == 0 ) dirp->d_first = 1;
}

