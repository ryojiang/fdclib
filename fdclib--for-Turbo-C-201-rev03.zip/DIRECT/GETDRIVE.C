#include <dos.h>

unsigned char __dogetdr( void );
#pragma aux __dogetdr = \
    "mov ah, 0x19"      \
    "int 0x21"          \
    value [al]          \
    modify [ax];

int _getdrive( void )
{
    return( __dogetdr( ) + 1 );
}
