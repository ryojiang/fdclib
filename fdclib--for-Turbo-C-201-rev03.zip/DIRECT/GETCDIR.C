#include <dir.h>

int __dogtdir( unsigned char drive, char *buffer );
#ifdef __CLIB_LFN__
#pragma aux __dogtdir = \
    "mov ax, 0x7147"    \
    "stc"               \
    "int 0x21"          \
    "jnc finish"        \
    "mov ah, 0x47"      \
    "int 0x21"          \
    "finish:"           \
    "sbb ax, ax"        \
    parm [dl] [si]      \
    value [ax]          \
    modify [ax dx si];
#else
#pragma aux __dogtdir = \
    "mov ah, 0x47"      \
    "int 0x21"          \
    "sbb ax, ax"        \
    parm [dl] [si]      \
    value [ax]          \
    modify [ax dx si];
#endif

int getcurdir( int drive, char *pathbuf )
{
    return( ( __dogtdir( ( unsigned char )drive, pathbuf ) < 0 ) ? -1 : 0 );
}
