#include <dir.h>
#include <string.h>
#include <dos.h>
#include <io.h>
#include <ctype.h>
#include <stdio.h>

static char __toalnum( char ch )
{
    while( ch < '0' ) ch++;
    while( ch > '9' && ch < 'A' ) ch++;
    while( ch > 'Z' && ch < 'a' ) ch++;
    while( ch > 'z' ) ch--;

    return( ch );
}

char *mktemp( char *template )
{
    struct dostime_t time;
    char *t = template;
    int i = TMP_MAX;
    static int j = 5;

    _dos_gettime( &time );

    while( *t != 'X' ) t++;

    if( strcmp( t, "XXXXXX" ) != 0 ) return( NULL );

    do {
        t = template;
        i--;

        if( j == 20 ) j = 5;

        while( *t != 'X' ) t++;

        *t++ = __toalnum( time.hour++ * j++ );
        *t++ = __toalnum( time.minute++ * j++ );
        *t++ = '.';
        *t++ = __toalnum( time.second++ * j++ );
        *t++ = __toalnum( time.hsecond++ * j++ );
        *t++ = __toalnum( time.hour++ * j++ );

        _dos_gettime( &time );
    } while( access( template, 0 ) == 0 && i );

    return( template );
}

