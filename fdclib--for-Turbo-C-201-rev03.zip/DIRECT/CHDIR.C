#include <direct.h>
#include <dos.h>
#include <errno.h>

int __dochdir( const char *path );
#pragma aux __dochdir = \
    "mov ah, 0x3B"      \
    "int 0x21"          \
    "sbb ax, ax"        \
    parm [dx]           \
    value [ax]          \
    modify [ax dx];

int chdir( const char *path )
{
    if( __dochdir( __retsfn( path ) ) < 0 ) {
        errno = ENOENT;
        return( -1 );
    }

    return( 0 );
}
