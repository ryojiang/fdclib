#include <dir.h>
#include <dos.h>
#include <string.h>
#include <stddef.h>
#include <malloc.h>
#include <errno.h>

char *getcwd( char *pathbuf, size_t length )
{
    return( _getdcwd( 0, pathbuf, length ) );
}

