#include <dir.h>
#include <dos.h>
#include <io.h>
#include <errno.h>

int __domkdir( const char *path );
#ifdef __CLIB_LFN__
#pragma aux __domkdir = \
    "mov ax, 0x7139"    \
    "stc"               \
    "int 0x21"          \
    "jnc finish"        \
    "mov ah, 0x39"      \
    "int 0x21"          \
    "finish:"           \
    "sbb ax, ax"        \
    parm [dx]           \
    value [ax]          \
    modify [ax dx];
#else
#pragma aux __domkdir = \
    "mov ah, 0x39"      \
    "int 0x21"          \
    "sbb ax, ax"        \
    parm [dx]           \
    value [ax]          \
    modify [ax dx];
#endif

int mkdir( const char *path, ... )
{
    if( __domkdir( path ) < 0 ) {
        errno = EACCES;
        return( -1 );
    }

    return( 0 );
}
