#include <dos.h>

unsigned char __dosetdr( unsigned char drv );
#pragma aux __dosetdr = \
    "mov ah, 0x0E"      \
    "int 0x21"          \
    parm [dl]           \
    value [al]          \
    modify [ax dx];

int setdisk( int disk )
{
    return( ( int )__dosetdr( ( unsigned char )disk ) );
}
