#include <dirent.h>
#include <dos.h>
#include <string.h>

struct dirent *readdir( DIR *dirp )
{
    if( dirp->d_first ) dirp->d_first = 0;
    else if( findnext( dirp ) ) return( NULL );

    dirp->d_loc++;
    dirp->d_namlen = strlen( dirp->d_name );

    return( dirp );
}
