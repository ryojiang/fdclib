#include <dos.h>
#include <dir.h>

unsigned char __dosetdr( unsigned char drv );
#pragma aux __dosetdr = \
    "mov ah, 0x0E"      \
    "int 0x21"          \
    parm [dl]           \
    value [al]          \
    modify [ax dx];

int _chdrive( int disk )
{
    __dosetdr( ( unsigned char )disk - 1 );

    return( ( _getdrive() != disk ) ? -1 : 0 );
}
