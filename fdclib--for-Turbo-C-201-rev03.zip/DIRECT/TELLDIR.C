#include <direct.h>

#undef telldir
long telldir( DIR *dirp )
{
    return( ( long )dirp->d_loc );
}
