#include <dos.h>
#include <string.h>

void __convert_to_find( void *buf, struct __lfnfind *temp )
{
    struct find_t *dest = buf;

    dest->attrib  = temp->attributes;
    dest->cr_time = temp->creattime;
    dest->cr_date = temp->creatdate;
    dest->ac_time = temp->accesstime;
    dest->ac_date = temp->accessdate;
    dest->wr_time = temp->wrtime;
    dest->wr_date = temp->wrdate;
    dest->size    = temp->filesize;
    if( temp->lfn ) {
        memcpy( dest->name, temp->lfn, 260 );
    } else {
        memcpy( dest->name, temp->sfn, 14 );
    }
}
