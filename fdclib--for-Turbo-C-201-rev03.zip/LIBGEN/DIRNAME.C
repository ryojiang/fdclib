#include <libgen.h>
#include <string.h>
#include <dir.h>
#include <sys/stat.h>

char *dirname( const char *path )
{
    static char retval[ _MAX_PATH ];
    char *p;

    strcpy( retval, path );

    if( path == NULL || *path == '\0' ) return( strcpy( retval, "." ) );

    p = strrchr( retval, '\\' );
    if( p == NULL ) p = strrchr( retval, '/' );

    if( p == NULL ) return( strcpy( retval, "." ) );

    if( p == ( char * )retval ) *( p + 1 ) = '\0';
    else  *p = '\0';

    p = retval + strlen( retval ) - 1;

    /* Skip trailing slashes */
    while( p > ( char * )retval + 1 ) {
        if( *p == '\\' ) *p = '\0';
        else break;
        p--;
    }

    return( retval );
}

