#include <libgen.h>
#include <string.h>
#include <dir.h>
#include <ctype.h>
#include <sys/stat.h>

char *basename( const char *name )
{
    static char retval[ _MAX_PATH ];
    char *base, *n;
    int len = 0;

    strcpy( retval, name );

    if( name == NULL ) return( strcpy( retval, "." ) );

    /* Skip over the disk name in MSDOS pathnames. */
    if( isalpha( name[ 0 ] ) && name[ 1 ] == ':' ) name += 2;

    for( base = retval, n = base; *n; n++ ) {
        if( *n == '/' || *n == '\\' ) {
            if( *( n + 1 ) == NULL ) {
                if( len == 0 ) return( n );
                *n = '\0';
                break;
            }
            base = n + 1;
        }
        len++;
    }
    
    return( base );
}

