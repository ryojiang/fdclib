#include <conio.h>
#include "globals.h"

void gotoxy( int x, int y )
{
    if( !__conio_initialized ) __initialize_conio();
    __gotoxy( x + __startx - 1, y + __starty - 1 );
}
