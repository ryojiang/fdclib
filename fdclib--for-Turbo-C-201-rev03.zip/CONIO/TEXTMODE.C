#include <conio.h>
#include "globals.h"

void __setmode( unsigned char mode );
#pragma aux __setmode = \
    "mov ah, 0x00"      \
    "int 0x10"          \
    parm [al]           \
    modify [ax];

void __enablec( void );
#pragma aux __enablec = \
    "mov ah, 0x12"      \
    "mov bl, 0x34"      \
    "mov al, 0x00"      \
    "int 0x10"          \
    modify [ax bx];

void __doubled( void );
#pragma aux __doubled = \
    "mov ax, 0x1112"    \
    "mov bx, 0"         \
    "int 0x10"          \
    modify [ax bx];

void textmode( int mode )
{
    int newmode = mode;

    if( !__conio_initialized ) __initialize_conio();
    if( mode == LASTMODE ) newmode = __orgmode;

    if( mode == C4350 ) newmode = 0x03;
    __setmode( newmode );

    if( mode == CO80 || mode == BW80 || mode == C4350 ) {
        if( __vidtype >= EGA ) __enablec();
    }

    if( mode == C4350 ) {
        if( __vidtype >= EGA ) __doubled();
    }

    __initialize_conio();
}
