#include <conio.h>
#include "globals.h"

void __doputch( unsigned char ch, unsigned char page, unsigned char attr );
#pragma aux __doputch = \
    "mov ah, 0x09"      \
    "mov cx, 1"         \
    "int 0x10"          \
    parm [al] [bh] [bl] \
    modify [ax bx cx];

int __putch( int ch )
{
    if( !__conio_initialized ) __initialize_conio();

    if( directvideo ) {
        unsigned scrnofs = ( ( __startx + __curx ) * __width * 2 ) +
                           ( ( __starty + __cury ) * 2 );
        __cgaenablevid( CGA_DISABLE );
        pokeb( __baseadr, scrnofs, ch );
        pokeb( __baseadr, scrnofs, __cur_attr );
        if( peekb( __baseadr, scrnofs ) & 0xFF != ch ) ch = EOF;
        __cgaenablevid( CGA_ENABLE );
    } else {
        __doputch( ch, __cur_page, __cur_attr );
    }
    
    return( ch );
}
