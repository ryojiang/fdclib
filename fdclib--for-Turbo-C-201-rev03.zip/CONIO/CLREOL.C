#include <conio.h>
#include "globals.h"

void clreol( void )
{
    if( !__conio_initialized ) __initialize_conio();
    __scroll( wherex(), wherey(), wherex(), __endy, __cur_attr, 0x06, 0 );
}
