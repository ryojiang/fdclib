#include <conio.h>
#include "globals.h"

void textcolor( int newattr )
{
    if( !__conio_initialized ) __initialize_conio();
    __cur_attr = ( __cur_attr & 0x70 ) | ( newattr & 0x8F );
}
