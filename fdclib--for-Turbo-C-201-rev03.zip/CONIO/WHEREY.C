#include <conio.h>
#include <dos.h>
#include "globals.h"

int wherey( void )
{
    if( !__conio_initialized ) __initialize_conio();
    return( peekb( 0, 0x451 ) - __starty + 1 );
}
