#include <conio.h>
#include "globals.h"

void textbackground( int newattr )
{
    if( !__conio_initialized ) __initialize_conio();
    __cur_attr = ( __cur_attr & 0x8F ) | ( ( newattr << 4 ) & 0x7F );
}
