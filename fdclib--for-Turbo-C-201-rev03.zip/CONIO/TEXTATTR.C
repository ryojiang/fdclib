#include <conio.h>
#include "globals.h"

void textattr( int newattr )
{
    if( !__conio_initialized ) __initialize_conio();
    __oldcolor = __cur_attr;
    __cur_attr = newattr;
}
