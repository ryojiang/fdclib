#include <conio.h>
#include <dos.h>
#include "globals.h"

int wherex( void )
{ 
    if( !__conio_initialized ) __initialize_conio();
    return( peekb( 0, 0x450 ) - __startx + 1 );
}
