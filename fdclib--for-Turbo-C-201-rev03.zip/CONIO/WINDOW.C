#include <conio.h>
#include "globals.h"

void window( int left, int top, int right, int bottom )
{
    if( left < 1 || right > __width + 1 || top < 1 || bottom > __length + 1 ||
        ( ( right - left ) < 0 || ( bottom - top ) < 0 ) ) return;

    __starty = top - 1;
    __startx = left - 1;
    __endy = bottom - 1;
    __endx = right - 1;
    __screenwidth = __endx - __startx;
    __screenheight = __endy - __starty;
    __curx = __cury = 0;
}
