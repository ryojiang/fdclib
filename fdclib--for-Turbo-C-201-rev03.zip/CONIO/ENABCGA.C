#include <conio.h>
#include <dos.h>
#include "globals.h"

void __cgaenablevid( unsigned char status )
{
    if( __vidtype == CGA )
        outportb( 0x3D8, status );
}
