#include <conio.h>

unsigned char __dostore( unsigned key );
#pragma aux __dostore = \
    "mov ah, 0x05"      \
    "int 0x16"          \
    parm [cx]           \
    value [al]          \
    modify [ax cx];

int ungetch( int ch )
{
    int key = 0;

    if( ch >= 256 ) {
        key = ch - 256;
        ch = 0xE0;
    }

    return( __dostore( ( key << 8 ) + ch ) ? EOF : ch );
}

