#include <conio.h>
#include <stdarg.h>
#include <_printf.h>
#include "globals.h"

int vcprintf( const char *format, va_list args )
{
    if( !__conio_initialized ) __initialize_conio();
    return( __vfnprintf( putch, format, args ) );
}

int cprintf( const char *format, ... )
{
    va_list args;

    va_start( args, format );

    return( vcprintf( format, args ) );
}
