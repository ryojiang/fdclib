#include <conio.h>
#include "keys.h"
#include "globals.h"

char *cgets( char *s )
{
    int ch, len = 0, maxlen = s[ 0 ] & 0xFF;
    char *p = s + 2;

    if( !__conio_initialized ) __initialize_conio();

    if( !maxlen ) maxlen = __screenwidth - __cury;

    while( ( ch = getch() ) != '\r' && ch != '\n' && ch != ESC && len < maxlen )
    {
        if( ch == '\b' ) {
            if ( len > 0 ) {
                cputs( "\b \b" );
                --len;
                --p;
            }
        } else if( ch < 32 || ch > 127 ) {
        } else {
            putch( ch );
            *p++ = ( char )ch;
            ++len;
        }
    }
    
    *p = '\0';
    s[ 1 ] = len;
    return( ( char * )( s + 2 ) );
}

