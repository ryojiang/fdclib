#include <conio.h>
#include "globals.h"

void highvideo( void )
{
    if( !__conio_initialized ) __initialize_conio();
    __cur_attr |= 0x08;
}
