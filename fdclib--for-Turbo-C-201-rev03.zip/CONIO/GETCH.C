#include <conio.h>

unsigned char __getch( void );
#pragma aux __getch = \
    "mov ah, 0x07"    \
    "int 0x21"        \
    value [al]        \
    modify [ax];

int getch( void )
{
    return( __getch() & 0xFF );
}
