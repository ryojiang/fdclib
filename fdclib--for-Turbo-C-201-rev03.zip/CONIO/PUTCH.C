#include <conio.h>

int putch( int ch )
{
    char buf[ 2 ];

    buf[ 0 ] = ( char )ch;
    buf[ 1 ] = '\0';
    return( cputs( buf ) );
}
