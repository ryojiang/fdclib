#include <conio.h>

unsigned char __getche( void );
#pragma aux __getche = \
    "mov ah, 0x01"    \
    "int 0x21"        \
    value [al]        \
    modify [ax];

int getche( void )
{
    return( __getche() & 0xFF );
}
