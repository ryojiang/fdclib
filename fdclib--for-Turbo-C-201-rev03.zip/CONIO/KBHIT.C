#include <conio.h>
#include "globals.h"

unsigned char __dokbhit( void );
#pragma aux __dokbhit = \
    "mov ah, 0x0B"      \
    "int 0x21"          \
    value [al]          \
    modify [ax];

int kbhit( void )
{
    return( ( int )__dokbhit() );
}
