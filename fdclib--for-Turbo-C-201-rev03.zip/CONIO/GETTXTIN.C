#include <conio.h>
#include "globals.h"

void gettextinfo( struct text_info *t )
{
    if( !__conio_initialized ) __initialize_conio();

    t->winleft =      ( unsigned char )__startx + 1;
    t->wintop =       ( unsigned char )__starty + 1;
    t->winright =     ( unsigned char )__endx + 1;
    t->winbottom =    ( unsigned char )__endy + 1;
    t->attribute =    ( unsigned char )__oldcolor;
    t->normattr =     ( unsigned char )__cur_attr;
    t->currmode =     ( unsigned char )__vidmode;
    t->screenheight = ( unsigned char )__screenheight + 1;
    t->screenwidth =  ( unsigned char )__screenwidth + 1;
    t->curx =         ( unsigned char )__curx + 1;
    t->cury =         ( unsigned char )__cury + 1;
}
