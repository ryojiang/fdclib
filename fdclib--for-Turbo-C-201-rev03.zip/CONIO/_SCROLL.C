#include <conio.h>
#include "globals.h"

void __doscrol( unsigned char func,
                unsigned char lines,
                unsigned char attr,
                unsigned char top,
                unsigned char left,
                unsigned char bottom,
                unsigned char right );
#pragma aux __doscrol = \
    "int 0x10"          \
    parm [ah] [al] [bh] [ch] [cl] [dh] [dl]\
    modify [ax bx cx dx];

void __scroll( int top,
               int left,
               int bottom,
               int right,
               int attr,
               int dir,
               int numlines )
{
    __doscrol( dir, numlines, attr, top, left, bottom, right );
}
