#include <conio.h>
#include "globals.h"

void insline( void )
{
    if( !__conio_initialized ) __initialize_conio();
    __scroll( wherex(),
              __starty,
              __endx,
              __endy,
              __cur_attr,
              0x07,
              ( wherex() == __endx ) ? 0 : 1 );
}
