#include <conio.h>
#include "globals.h"

void __dogotxy( unsigned char x, unsigned char y, unsigned char page );
#pragma aux __dogotxy = \
    "mov ah, 0x02"      \
    "int 0x10"          \
    parm [dl] [dh] [bh] \
    modify [ax bx dx];

void __gotoxy( unsigned char x, unsigned char y )
{
    __dogotxy( x, y, __cur_page );
}

