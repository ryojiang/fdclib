#include <conio.h>
#include <stdarg.h>
#include <_printf.h>
#include "globals.h"

int cscanf( char *format, ... )
{
    va_list args;

    if( !__conio_initialized ) __initialize_conio();

    va_start( args, format );
    return( __vfnscanf( ( void (*)( char *m ) )__cgets, format, args ) );
    va_end( args );
}
