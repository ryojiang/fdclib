#include <dos.h>
#include <conio.h>

void __beep( void )
{
#if 0
    long divisor = 1192;
    int hibyte = divisor >> 8, lobyte = 168;

    outportb( 67, 187 );    /* Prepare the timer */
    outportb( 66, 168 );
    outportb( 66, hibyte );
    outportb( 97, 79 );     /* Turn the speaker on */
#else
    sound( 900 );
#endif

    delay( 100 );

#if 0

    outportb( 97, inportb( 97 ) & 0xFC ); /* Turn speaker off */
#else
    nosound();
#endif
}
