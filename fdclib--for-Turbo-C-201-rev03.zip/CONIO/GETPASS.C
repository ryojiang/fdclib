#include <conio.h>
#include "keys.h"

char *getpass( const char *prompt )
{
    int ch, len = 0;
    static char s[10];
    char *p = s;

    cputs( prompt );

    while( ( ch = getch() ) != '\r' && ch != '\n' && ch != ESC && len < 9 ) {
        if( ch == '\b' ) {
            if( len > 0 ) {
                cputs( "\b \b" );
                len--;
                *p--;
            }
        } else if( ch < 32 || ch > 127 ) {
        } else {
            *p++ = ( char )ch;
            len++;
        }
    }

    *p = '\0';

    return( s );
}
