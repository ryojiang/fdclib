#include <conio.h>

int __startx,
    __starty,
    __endx,
    __endy,
    __screenwidth,
    __screenheight,
    __curx = 0,
    __cury = 0,
    __cur_attr = 7,
    __old_mode = 0,
    __oldcolor = 7,
    __cur_mode = 7,
    __vidtype = 0,
    __vidmode = -1,
    __orgmode = -1,
    __chbuf = -1,
    __kb_flag = 0,
    __sort_order,
    __reverse_order,
    directvideo = 1,
    _wscroll = 1;

unsigned char __cur_page = 0,
              __buff[ 4096 ],
              __box_chars[ 101 ],
              __conio_initialized = 0;

unsigned int __width = 0,
             __length = 0,
             __baseadr = 0;

