#include <conio.h>
#include "globals.h"

void clrscr( void )
{
    if( !__conio_initialized ) __initialize_conio();
    __scroll( __startx, __starty, __endx, __endy, __cur_attr, 0x06, 0 );
    gotoxy( __startx, __starty );
    __curx = __cury = 0;
}
