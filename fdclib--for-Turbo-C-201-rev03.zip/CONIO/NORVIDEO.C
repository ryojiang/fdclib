#include <conio.h>
#include "globals.h"

void normvideo( void )
{
    if( !__conio_initialized ) __initialize_conio();
    __cur_attr = __oldcolor;
}
