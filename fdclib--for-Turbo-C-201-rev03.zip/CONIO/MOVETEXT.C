#include <conio.h>
#include <malloc.h>
#include "globals.h"

int movetext( int l, int top, int r, int bottom, int dl, int dt )
{
    char *buf = malloc( ( ( r - l ) * ( bottom - top ) ) * 2 );

    if( !gettext( l, top, r, bottom, buf ) ) {
        free( buf );
        return( 0 );
    }
    if( !puttext( dl, dt, dl + ( r - l ), dt + ( bottom - top ), buf ) ) {
    free( buf );
    return( 0 );
    };

    free( buf );
    return( 1 );
}
