#include <search.h>
#include "internal.h"

void remque( void *elem )
{
    struct __qelem *e = elem;

    e->q_forw->q_back = e->q_back;
    e->q_back->q_forw = e->q_forw;
}

