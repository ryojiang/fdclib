#include <search.h>
#include <string.h>

void *lsearch( const void *key, void *base, size_t *nelp, size_t width,
               int ( *compar )( const void *m1, const void *m2 ) )
{
    void *ret_find = lfind( key, base, nelp, width, compar );
    char *b = base;
    
    if( ret_find != NULL ) return( ret_find );
    
    memcpy( b + ( *nelp * width ), key, width );
    ( *nelp )++;
    
    return( base );
}

