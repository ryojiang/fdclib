#include <search.h>
#include "internal.h"

void insque( void *elem, void *pred )
{
    struct __qelem *e = elem;
    struct __qelem *p = pred;

    e->q_forw = p->q_forw;
    p->q_forw->q_back = e;
    e->q_back = p;
    p->q_forw = e;
}

