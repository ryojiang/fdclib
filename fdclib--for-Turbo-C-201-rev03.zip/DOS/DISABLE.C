#include <dos.h>

void __cli( void );
#pragma aux __cli = "cli";

void _disable( void )
{
    __cli();
}
