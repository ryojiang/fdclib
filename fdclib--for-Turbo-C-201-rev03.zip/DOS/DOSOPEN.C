#include <dos.h>
#include <errno.h>

int __dodopen( const char *path, unsigned char flags );
#pragma aux __dodopen = \
    "mov ah, 0x3D"      \
    "int 0x21"          \
    "jnc finish"        \
    "mov errno, ax"     \
    "mov _doserrno, ax" \
    "sbb ax, ax"        \
    "finish:"           \
    parm [dx] [al]      \
    value [ax]          \
    modify [ax cx bx dx];

#undef _dos_open

unsigned _dos_open( const char *path, unsigned flags, unsigned *handle )
{
    register int retval = __dodopen( path, ( unsigned char )flags );

    if( retval < 0 ) return( _doserrno );

    *handle = retval;

    return( 0 );
}
