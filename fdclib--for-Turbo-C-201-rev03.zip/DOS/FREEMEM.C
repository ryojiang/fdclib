#include <dos.h>
#include <errno.h>

int __dodfree( unsigned seg );
#pragma aux __dodfree = \
    "push es"           \
    "mov es, ax"        \
    "mov ah, 0x49"      \
    "int 0x21"          \
    "sbb ax, ax"        \
    "pop es"            \
    parm [ax]           \
    value [ax]          \
    modify [ax];

int freemem( unsigned seg )
{
    register int retval = __dodfree( seg );

    if( retval < 0 ) {
        errno = _doserrno = ENOMEM;
        return( -1 );
    }

    return( 0 );
}
