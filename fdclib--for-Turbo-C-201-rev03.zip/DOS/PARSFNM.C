#include <dos.h>

char *__doparse( const char *cmdline, void *buf, unsigned char al );
#pragma aux __doparse = \
    "mov ah, 0x29"      \
    "int 0x21"          \
    "cmp al, 0xFF"      \
    "mov ax, 0"         \
    "jz short return"   \
    "mov ax, si"        \
    "return:"           \
    parm [si] [di] [al] \
    value [ax]          \
    modify [ax si di];

char *parsfnm( const char *cmdline, struct fcb *ptr, int al )
{
    return( __doparse( __retsfn( cmdline ), ptr, ( unsigned char )al ) );
}