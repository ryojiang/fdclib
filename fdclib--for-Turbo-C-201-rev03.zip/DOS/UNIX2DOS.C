#include <stddef.h>
#include <dos.h>
#include <time.h>

void unixtodos( time_t longtime, struct date *date, struct time *time )
{
    struct tm *unixtime = localtime( &longtime );
    
    time->ti_sec = unixtime->tm_sec;
    time->ti_min = unixtime->tm_min;
    time->ti_hour = unixtime->tm_hour;
    time->ti_hund = 0;
    date->da_day = unixtime->tm_mday;
    date->da_mon = unixtime->tm_mon + 1;
    date->da_year = unixtime->tm_year + 1900;
}
