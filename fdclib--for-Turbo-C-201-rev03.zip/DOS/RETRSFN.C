#include <dos.h>
#include <fcntl.h>
#include <stdlib.h>

#undef _dos_open /* using this on NUL seems to fail */

const char *__retrsfn( const char *filename )
{
    static char resolved[ 260 ];
    unsigned handle;

    if( !_dos_open( filename, O_RDONLY, &handle ) ) {
        _dos_close( handle );
        
        return( filename );
    }

    if( realpath( filename, resolved ) != NULL )
        return( __retsfn( resolved ) );
    else return( __retsfn( filename ) );
}

