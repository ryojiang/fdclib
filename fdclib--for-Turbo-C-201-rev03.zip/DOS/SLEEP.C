#include <dos.h>

void sleep( unsigned x )
{
    unsigned i = 0;
    unsigned s;
    struct dostime_t n;               /* current time record */

    _dos_gettime( &n );
    s = n.second;

    while( i < x ){
        while( s == n.second )
            _dos_gettime( &n );
        s = n.second;
        ++i;
    }
}

