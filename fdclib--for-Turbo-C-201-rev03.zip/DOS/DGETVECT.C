#include <dos.h>

void ( interrupt far *__dogetvt( unsigned char intno ) )( );
#pragma aux __dogetvt = \
    "mov ah, 0x35"      \
    "int 0x21"          \
    parm [al]           \
    value [es bx]       \
    modify [ax es bx];

void ( interrupt far *_dos_getvect( unsigned intno ) )( )
{
    return( __dogetvt( ( unsigned char )intno ) );
}
