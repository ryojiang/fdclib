#include <dos.h>

int __doabswr( unsigned char drive, int sects, int lsect, void *buffer );
#pragma aux __doabswr = \
    "push bp"           \
    "int 0x26"          \
    "sbb ax, ax"        \
    "popf"              \
    "pop bp"            \
    parm [al] [cx] [dx] [bx]\
    value [ax]\
    modify [ax bx cx dx si di];

int abswrite( int drive, int sects, long lsect, void *buffer )
{
    return( __doabswr( drive, sects, ( int )lsect, buffer ) );
}
