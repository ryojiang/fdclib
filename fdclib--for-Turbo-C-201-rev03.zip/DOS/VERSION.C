#include <dos.h>

static int __version = 0;

int *__getversion( void )
{
    if( __version == 0 ) __version = ( _osminor << 8 ) | ( _osmajor & 0xFF );
    return( &__version );
}

