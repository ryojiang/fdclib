#include <dos.h>

unsigned char __dogcbrk( void );
#pragma aux __dogcbrk = \
    "mov ax, 0x3300"    \
    "int 0x21"          \
    value [dl]          \
    modify [ax dx];

int getcbrk( void )
{
    return( ( int )__dogcbrk() );
}
