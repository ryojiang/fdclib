#define __NO_INLINE_FUNCTIONS

#include <dos.h>

void __dooutpt( unsigned id, unsigned char value );
#pragma aux __dooutpt = \
    "out dx, al"        \
    parm [dx] [al]      \
    modify [ax dx];

void outportb( unsigned id, unsigned char value )
{
    __dooutpt( id, value );
}
