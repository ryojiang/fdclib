#include <dos.h>

void __sti( void );
#pragma aux __sti = "sti";

void _enable( void )
{
    __sti();
}
