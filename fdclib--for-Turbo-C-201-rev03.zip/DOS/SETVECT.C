#include <dos.h>

void __dosetvt( unsigned char intno, void ( interrupt far *vect )() );
#pragma aux __dosetvt = \
    "mov ah, 0x25"      \
    "push ds"           \
    "mov ds, cx"        \
    "int 0x21"          \
    "pop ds"            \
    parm [al] [cx dx]   \
    modify [ax cx dx];

void setvect( int intno, void ( interrupt far *vect )() )
{
    __dosetvt( ( unsigned char )intno, vect );
}
