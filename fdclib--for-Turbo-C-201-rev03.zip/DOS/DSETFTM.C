#include <dos.h>
#include <errno.h>

int __dosetft( int handle, unsigned date, unsigned time );
#pragma aux __dosetft = \
    "mov ax, 0x5701"    \
    "int 0x21"          \
    "jnc finish"        \
    "mov _doserrno, ax" \
    "finish:"           \
    "sbb ax, ax"        \
    parm [bx] [dx] [cx] \
    value [ax]          \
    modify [ax bx cx dx];

unsigned _dos_setftime( int handle, unsigned date, unsigned time )
{
    register int retval = __dosetft( handle, date, time );

    if( retval < 0 ) {
        errno = EBADF;
        return( _doserrno );
    }

    return( 0 );
}
