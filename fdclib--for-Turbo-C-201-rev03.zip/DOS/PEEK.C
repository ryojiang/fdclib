#include <dos.h>

#undef peek

int peek( unsigned seg, unsigned offs )
{
    return( __peek( seg, offs ) );
}
