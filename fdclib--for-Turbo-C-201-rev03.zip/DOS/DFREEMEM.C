#include <dos.h>
#include <errno.h>

int __dodfree( unsigned seg );
#pragma aux __dodfree = \
    "push es"           \
    "mov es, ax"        \
    "mov ah, 0x49"      \
    "int 0x21"          \
    "jnc finish"        \
    "mov _doserrno, ax" \
    "finish:"           \
    "sbb ax, ax"        \
    "pop es"            \
    parm [ax]           \
    value [ax]          \
    modify [ax];

unsigned _dos_freemem( unsigned seg )
{
    register int retval = __dodfree( seg );

    if( retval < 0 ) {
        errno = ENOMEM;
        return( _doserrno );
    }

    return( 0 );
}

