#include <dos.h>

int __dobdos( unsigned char ah, unsigned dx, unsigned char al );
#pragma aux __dobdos =  \
    "int 0x21"          \
    parm [ah] [dx] [al] \
    value [ax]          \
    modify [ax bx cx dx si di];

int bdos( int ah, unsigned dx, unsigned al )
{
    return( __dobdos( ah, dx, al ) );
}
