#include <dos.h>
#include <errno.h>

int __dobdpt( unsigned char ah,
              unsigned offset,
              unsigned char al );
#pragma aux __dobdpt =  \
    "int 0x21"          \
    "jnc end"           \
    "mov errno, ax"     \
    "mov _doserrno, ax" \
    "sbb ax, ax"        \
    "end:"              \
    parm [ah] [dx] [al] \
    value [ax]          \
    modify [ax bx cx dx si di];

int bdosptr( int ah, void *argument, unsigned al )
{
    register int retval = __dobdpt( ( unsigned char )ah,
                                    FP_OFF( argument ),
                                    al );
    
    if( retval < 0 ) return( retval );

    return( retval );
}

