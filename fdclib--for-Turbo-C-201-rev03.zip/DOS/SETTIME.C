#include <dos.h>
#include <errno.h>

void __dosettm( unsigned char hour,
                unsigned char minute,
                unsigned char second,
                unsigned char msecond );
#pragma aux __dosettm = \
    "mov ah, 0x2D"      \
    "int 0x21"          \
    parm [ch] [cl] [dh] [dl]\
    modify [ax cx dx];

void settime( struct time *tp )
{
    __dosettm( tp->ti_hour, tp->ti_min, tp->ti_sec, tp->ti_hund );
}
