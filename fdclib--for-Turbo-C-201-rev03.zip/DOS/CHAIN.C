#include <dos.h>
#include <errno.h>
#include <string.h>
#include <stdlib.h>

int _chain( const char *path, const char *cmdline )
{
    register int retval = _exec( path, cmdline );

    if( retval < 0 ) return( -1 );

    exit( retval );

    return( -1 );
}

