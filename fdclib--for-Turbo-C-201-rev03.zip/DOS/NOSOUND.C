#include <dos.h>

void __donsond( void );
#pragma aux __donsond = \
    "in al, 0x61"       \
    "and al, 0xFC"      \
    "out 0x61, al"      \
    modify [ax];

void nosound( void )
{
    __donsond();
}
