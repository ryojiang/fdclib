#include <dos.h>

unsigned char __dorandr( void *buf, int rnum );
#pragma aux __dorandr = \
    "mov ah, 0x27"      \
    "int 0x21"          \
    parm [dx] [cx]      \
    value [al]          \
    modify [ax cx dx];

int randbrd( struct fcb *buf, int rnum )
{
    return( ( int )__dorandr( buf, rnum ) );
}
