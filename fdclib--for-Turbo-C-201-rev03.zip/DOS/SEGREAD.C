#include <dos.h>

void segread( struct SREGS *segs )
{
    union _INTR r;

    _segread( &r );
    memcpy( segs, &r + 18, sizeof( struct SREGS ) );
}
