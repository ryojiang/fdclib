#include <dos.h>

#undef poke

void poke( unsigned seg, unsigned offs, int value )
{
    __poke( seg, offs, value );
}
