#include <dos.h>
#include <stdlib.h>

static int ( *__althandler )( void );

/*
 * This function will exit if the user�s ctrl-break handler returns 0
 */
static void __ctrlhandler( void )
{
    if( !( *__althandler )( ) ) _exit( 0 );
}

void ctrlbrk( int ( *handler )( void ) )
{
    __althandler = handler;
    _dos_setvect( 0x23, ( void ( interrupt far * )() )__ctrlhandler );
}