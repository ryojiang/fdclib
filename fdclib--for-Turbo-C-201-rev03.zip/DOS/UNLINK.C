#include <dos.h>
#include <errno.h>

int __dounlnk( const char *filename );
#pragma aux __dounlnk = \
    "mov ah, 0x41"      \
    "int 0x21"          \
    "sbb ax, ax"        \
    parm [dx]           \
    modify [ax dx];

int unlink( const char *filename )
{
    if( __dounlnk( __retsfn( filename ) ) < 0 ) {
        errno = ENOENT;
        return( -1 );
    }

    return( 0 );
}
