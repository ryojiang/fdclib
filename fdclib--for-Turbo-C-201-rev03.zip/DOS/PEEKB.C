#include <dos.h>

#undef peekb

char peekb( unsigned seg, unsigned offs )
{
    return( __peekb( seg, offs ) );
}
