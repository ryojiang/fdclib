#include <dos.h>
#include <errno.h>

void __dosdate( unsigned char day, unsigned char month, int year );
#pragma aux __dosdate = \
    "mov ah, 0x2B"      \
    "int 0x21"          \
    parm [dl] [dh] [cx] \
    modify [ax cx dx];

void _dos_setdate( struct dosdate_t *ptr )
{
    __dosdate( ptr->day, ptr->month, ptr->year );
}
