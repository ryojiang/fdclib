#define __NO_INLINE_FUNCTIONS

#include <dos.h>

void __dooutpt( unsigned id, unsigned value );
#pragma aux __dooutpt = \
    "out dx, ax"        \
    parm [dx] [ax]      \
    modify [ax ax];

void outport( unsigned id, unsigned value )
{
    __dooutpt( id, value );
}
