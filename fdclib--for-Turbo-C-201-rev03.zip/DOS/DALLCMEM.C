#include <dos.h>
#include <errno.h>

int __doalloc( unsigned size );
#pragma aux __doalloc = \
    "mov ah, 0x48"      \
    "int 0x21"          \
    "jnc finish"        \
    "mov _doserrno, ax" \
    "sbb ax, ax"    \
    "finish:"           \
    parm [bx]           \
    value [ax]          \
    modify [ax bx];

unsigned _dos_allocmem( unsigned size, unsigned *seg )
{
    register int retval = __doalloc( size );

    if( retval < 0 ) {
        errno = ENOMEM;
        return( _doserrno );
    }

    *seg = retval;

    return( 0 );
}

