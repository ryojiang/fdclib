#include <dos.h>

unsigned char __dogetsw( void );
#pragma aux __dogetsw = \
    "mov ax, 0x3700"    \
    "int 0x21"          \
    "cmp al, 0xFF"      \
    "jnz finish"        \
    "mov dl, 0x2F"/*/ */\
    "finish:"           \
    value [dl]          \
    modify [ax dx];

unsigned char _getswitch( void )
{
    return( __dogetsw() );
}
