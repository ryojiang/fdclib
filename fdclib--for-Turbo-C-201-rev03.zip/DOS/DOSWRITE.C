#include <dos.h>
#include <errno.h>

int __dowrite( int handle, void far *buf, unsigned len );
#pragma aux __dowrite = \
    "mov ah, 0x40"      \
    "int 0x21"          \
    "jnc finish"        \
    "mov errno, ax"     \
    "mov _doserrno, ax" \
    "sbb ax, ax"        \
    "finish:"           \
    parm [bx] [dx] [cx] \
    value [ax]          \
    modify [ax bx cx dx];

unsigned _dos_write( int handle, void far *buf, unsigned len, unsigned *bytes )
{
    register int retval = __dowrite( handle, buf, len );

    if( retval < 0 ) return( _doserrno );

    *bytes = retval;

    return( 0 );
}
