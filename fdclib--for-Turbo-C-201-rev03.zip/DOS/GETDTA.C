#include <dos.h>

char *__dogtdta( void );
#pragma aux __dogtdta = \
    "mov ah, 0x2F"      \
    "int 0x21"          \
    value [bx]          \
    modify [ax bx];

char *getdta( void )
{
    return( __dogtdta( ) );
}
