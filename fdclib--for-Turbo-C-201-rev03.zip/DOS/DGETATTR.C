#include <dos.h>
#include <errno.h>

int __dogtatr( const char *filename );
#pragma aux __dogtatr = \
    "mov ax, 0x4300"    \
    "int 0x21"          \
    "jnc finish"        \
    "mov errno, ax"     \
    "mov _doserrno, ax" \
    "mov cx, 0xFFFF"    \
    "finish:"           \
    parm [dx]           \
    value [cx]          \
    modify [ax dx cx];

unsigned _dos_getfileattr( const char *filename, unsigned *attrs )
{
    register int retval = __dogtatr( __retsfn( filename ) );

    if( retval < 0 ) {
        return( _doserrno );
    }

    *attrs = retval;

    return( 0 );
}

