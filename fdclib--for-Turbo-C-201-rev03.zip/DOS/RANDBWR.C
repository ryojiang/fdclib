#include <dos.h>

unsigned char __dorandw( void *buf, int rnum );
#pragma aux __dorandw = \
    "mov ah, 0x28"      \
    "int 0x21"          \
    parm [dx] [cx]      \
    value [al]          \
    modify [ax cx dx];

int randbwr( struct fcb *buf, int rnum )
{
    return( ( int )__dorandw( buf, rnum ) );
}
