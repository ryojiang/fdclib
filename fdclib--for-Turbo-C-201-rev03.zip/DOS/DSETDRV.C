#include <dos.h>

unsigned char __dosetdr( unsigned char drv );
#pragma aux __dosetdr = \
    "mov ah, 0x0E"      \
    "int 0x21"          \
    parm [dl]           \
    value [al]          \
    modify [ax dx];

void _dos_setdrive( unsigned disk, unsigned *total )
{
    *total = ( unsigned )__dosetdr( ( unsigned char )disk - 1 );
}
