#include <dos.h>

int __doabsrd( unsigned char drive, int sects, int lsect, void *buffer );
#pragma aux __doabsrd = \
    "push bp"           \
    "int 0x25"          \
    "sbb ax, ax"        \
    "popf"              \
    "pop bp"            \
    parm [al] [cx] [dx] [bx]\
    value [ax]\
    modify [ax bx cx dx si di];

int absread( int drive, int sects, long lsect, void *buffer )
{
    return( __doabsrd( drive, sects, ( int )lsect, buffer ) );
}
