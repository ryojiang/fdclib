#include <dos.h>
#include <errno.h>

int __dostatr( const char *filename, unsigned attrs );
#pragma aux __dostatr = \
    "mov ax, 0x4301"    \
    "int 0x21"          \
    "jnc finish"        \
    "mov errno, ax"     \
    "mov _doserrno, ax" \
    "sbb ax, ax"        \
    "finish:"           \
    parm [dx] [cx]      \
    value [ax]          \
    modify [ax dx cx];

unsigned _dos_setfileattr( const char *filename, unsigned attrs )
{
    register int retval = __dostatr( __retsfn( filename ), attrs );

    if( retval < 0 ) {
        return( _doserrno );
    }

    return( 0 );
}
