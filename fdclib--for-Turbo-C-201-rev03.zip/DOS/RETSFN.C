#include <dos.h>
#include <fcntl.h>

int __getsfnm( const char *longfilename, char far *shortfilename );
#pragma aux __getsfnm = \
    "mov ax, 0x7160"    \
    "mov cx, 0x8001"    \
    "stc"               \
    "int 0x21"          \
    "sbb ax, ax"        \
    parm [si] [es di]   \
    value [ax]          \
    modify [ax cx si di];

#undef _dos_open /* using this on NUL seems to fail */

const char *__retsfn( const char *filename )
{
    static char shortfilename[ 128 ];
    unsigned handle;

    if( !_dos_open( filename, O_RDONLY, &handle ) ) {
        _dos_close( handle );
        
        return( filename );
    }

    return( ( __getsfnm( filename, shortfilename ) < 0 ) ?
            filename :
            shortfilename );
}
