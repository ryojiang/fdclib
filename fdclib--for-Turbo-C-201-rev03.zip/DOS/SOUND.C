#include <dos.h>

void __dosound( unsigned freq );
#pragma aux __dosound = \
    "mov ax, 0x34DD"    \
    "mov dx, 0x0012"    \
    "cmp dx, bx"        \
    "jnb none"          \
    "div bx"            \
    "mov bx, ax"        \
    "in  al, 0x61"      \
    "test    al, 3"     \
    "jne j1"            \
    "or  al, 3"         \
    "out 0x61, al"      \
    "mov al, 0xB6"      \
    "out 0x43, al"      \
    "j1:"               \
    "mov al, bl"        \
    "out 0x42, al"      \
    "mov al, bh"        \
    "out 0x42, al"      \
    "none:"             \
    parm [bx]           \
    modify [ax bx dx];

void sound( unsigned frequency )
{
    __dosound( frequency );
}
