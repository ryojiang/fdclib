#define __NO_INLINE_FUNCTIONS

#include <dos.h>

unsigned char __doinprt( unsigned id );
#pragma aux __doinprt = \
    "in al, dx"         \
    parm [dx]           \
    value [al]          \
    modify [ax dx];

unsigned char inportb( unsigned id )
{
    return( __doinprt( id ) );
}
