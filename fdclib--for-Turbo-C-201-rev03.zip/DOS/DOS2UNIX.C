#include <stddef.h>
#include <dos.h>
#include <time.h>

time_t dostounix( struct date *date, struct time *time )
{
    struct tm unixtime;

    unixtime.tm_sec = time->ti_sec;
    unixtime.tm_min = time->ti_min;
    unixtime.tm_hour = time->ti_hour;
    unixtime.tm_mday = date->da_day;
    unixtime.tm_mon = date->da_mon - 1;
    unixtime.tm_year = date->da_year - 1900;
    unixtime.tm_isdst = 0;
    
    return( mktime( &unixtime ) );
}