#include <dos.h>

#undef pokeb

void pokeb( unsigned seg, unsigned offs, char value )
{
    __pokeb( seg, offs, value );
}
