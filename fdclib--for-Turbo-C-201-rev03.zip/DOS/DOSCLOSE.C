#include <dos.h>
#include <errno.h>

int __doclose( int handle );
#pragma aux __doclose = \
    "mov ah, 0x3E"      \
    "int 0x21"          \
    "jnc finish"        \
    "mov _doserrno, ax" \
    "sbb ax, ax"        \
    "finish:"           \
    parm [bx]           \
    value [ax]          \
    modify [ax bx];

unsigned _dos_close( int handle )
{
    register int retval = __doclose( handle );

    if( retval < 0 ) {
        errno = EBADF;
        return( _doserrno );
    }

    return( 0 );
}
