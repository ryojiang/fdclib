#include <dos.h>
#include <errno.h>

int __dodread( int handle, void far *buf, unsigned len );
#pragma aux __dodread = \
    "mov ah, 0x3F"      \
    "int 0x21"          \
    "jnc finish"        \
    "mov errno, ax"     \
    "mov _doserrno, ax" \
    "sbb ax, ax"        \
    "finish:"           \
    parm [bx] [dx] [cx] \
    value [ax]          \
    modify [ax bx cx dx];

unsigned _dos_read( int handle, void far *buf, unsigned len, unsigned *nread )
{
    register int retval = __dodread( handle, buf, len );

    if( retval < 0 ) {
        return( _doserrno );
    }

    *nread = retval;

    return( 0 );
}
