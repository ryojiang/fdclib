#include <dos.h>
#include <errno.h>

int __dostblk( unsigned newsize, unsigned seg );
#pragma aux __dostblk = \
    "mov ah, 0x4A"      \
    "push es"           \
    "mov es, cx"        \
    "int 0x21"          \
    "pop es"            \
    "jnc finish"        \
    "mov _doserrno, ax" \
    "mov bx, 0xFFFF"    \
    "finish:"           \
    parm [bx] [cx]      \
    value [bx]          \
    modify [ax bx cx];

int setblock( unsigned newsize, unsigned seg )
{
    register int retval = __dostblk( newsize, seg );

    if( retval < 0 ) {
        errno = ENOMEM;
        return( _doserrno );
    }

    return( -1 );
}
