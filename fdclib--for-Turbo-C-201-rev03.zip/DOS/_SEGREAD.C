#include <dos.h>

void __segread( void *regs );
#if defined __COMPACT__ || defined __LARGE__ || defined __HUGE__
#pragma aux __segread = \
    "mov [di+4*2],sp"   \
    "mov [di+5*2],bp"   \
    "mov [di+8*2],es"   \
    "mov [di+9*2],cs"   \
    "mov [di+10*2],ss"  \
    "mov [di+11*2],ds"  \
    "pushf" "pop ax"    \
    "mov [di+12*2],ax"  \
    "and ax,1"          \
    "mov [di+13*2],ax"  \
    parm [ds di] nomemory \
    modify exact [ax] nomemory;
#else
#pragma aux __segread = \
    "mov [di+4*2],sp"   \
    "mov [di+5*2],bp"   \
    "mov [di+8*2],es"   \
    "mov [di+9*2],cs"   \
    "mov [di+10*2],ss"  \
    "mov [di+11*2],ds"  \
    "pushf" "pop ax"    \
    "mov [di+12*2],ax"  \
    "and ax,1"          \
    "mov [di+13*2],ax"  \
    parm [di] nomemory  \
    modify exact [ax] nomemory;
#endif

void _segread( void *r )
{
    __segread( r );
}

