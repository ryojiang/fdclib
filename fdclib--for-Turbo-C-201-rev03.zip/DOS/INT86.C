#include <dos.h>
#include <string.h>

/*
 * Borland/Watcom-alike intr function.  Use "void *" because a program
 * designed for Watcom would use "union REGPACK" and a program designed
 * for the Borland family of compilers would use "struct REGPACK".
 * Also, programs designed for this CLIB can also use "union _INTREGS" or
 * "union _INTR" (some compilers only).
 */
int int86( int intno, union REGS *inregs, union REGS *outregs )
{
    union _INTR r;

    memcpy( &r, inregs, sizeof( union REGS ) );
    _segread( &r );
    r.w.flags = inregs->x.flags;                 /* modified by Jau-Bing Lin */
    _callint( intno, &r, &r );
    memcpy( outregs, &r, sizeof( union REGS ) );
    outregs->x.flags = r.w.flags;                /* modified by Jau-Bing Lin */
    outregs->x.cflag = r.w.cflag;                /* modified by Jau-Bing Lin */

    return( r.w.ax );                            /* modified by Jau-Bing Lin */
}