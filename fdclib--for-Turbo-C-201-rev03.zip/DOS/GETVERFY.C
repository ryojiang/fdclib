#include <dos.h>

unsigned char __dogtvfy( void );
#pragma aux __dogtvfy = \
    "mov ah, 0x54"      \
    "int 0x21"          \
    value [al]          \
    modify [ax];

int getverify( void )
{
    return( ( int )__dogtvfy() );
}
