#define __NO_INLINE_FUNCTIONS

#include <dos.h>

unsigned char __dooutpt( unsigned id, unsigned char value );
#pragma aux __dooutpt = \
    "out dx, al"        \
    parm [dx] [al]      \
    value [al]          \
    modify [ax dx];

int outp( unsigned id, int value )
{
    return( ( int )__dooutpt( id, ( unsigned char )value ) );
}
