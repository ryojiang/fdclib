#define __NO_INLINE_FUNCTIONS

#include <dos.h>

unsigned char __doinprt( unsigned id );
#pragma aux __doinprt = \
    "in al, dx"         \
    parm [dx]           \
    value [al]          \
    modify [ax dx];

int inp( unsigned id )
{
    return( ( int )__doinprt( id ) );
}
