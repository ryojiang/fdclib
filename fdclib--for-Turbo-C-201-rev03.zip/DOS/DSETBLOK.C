#include <dos.h>
#include <errno.h>

int __dostblk( unsigned newsize, unsigned seg, unsigned *max );
#pragma aux __dostblk = \
    "mov ah, 0x4A"      \
    "push es"           \
    "mov es, cx"        \
    "int 0x21"          \
    "pop es"            \
    "mov [di], bx"      \
    "jnc finish"        \
    "mov _doserrno, ax" \
    "finish:"           \
    "sbb ax, ax"        \
    parm [bx] [cx] [di] \
    value [ax]          \
    modify [ax bx cx di];

unsigned _dos_setblock( unsigned newsize, unsigned seg, unsigned *max )
{
    register int retval = __dostblk( newsize, seg, max );

    if( retval < 0 ) {
        errno = ENOMEM;
        return( _doserrno );
    }

    return( 0 );
}
