#include <dos.h>

void __dodkeep( unsigned char retcode, unsigned pars );
#pragma aux __dodkeep = \
    "mov ah, 0x31"      \
    "int 0x21"          \
    parm [al] [dx];

void _dos_keep( unsigned char retcode, unsigned size )
{
    __dodkeep( retcode, size );
}
