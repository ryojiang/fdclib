#include <dos.h>

unsigned __dogtpsp( void );
#pragma aux __dogtpsp = \
    "mov ah, 0x62"      \
    "int 0x21"          \
    value [bx]          \
    modify [ax bx];

unsigned getpsp( void )
{
    return( __dogtpsp() );
}
