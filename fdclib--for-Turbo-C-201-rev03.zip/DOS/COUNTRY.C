#include <dos.h>
#include <stddef.h>

int __docount( int code, struct country *ct );
#pragma aux __docount = \
    "cmp al, 0xFF"      \
    "jnz doint"         \
    "mov bx, ax"        \
    "doint:"            \
    "mov ah, 0x38"      \
    "int 0x21"          \
    "sbb ax, ax"        \
    parm [ax] [dx]      \
    value [ax]          \
    modify [ax bx dx];

struct country *country( int xcode, struct country *ct )
{
    return( ( __docount( xcode, ct ) < 0 ) ? NULL : ct );
}

