#include <dos.h>

void __dostdta( char far *dta );
#pragma aux __dostdta = \
    "mov ah, 0x1A"      \
    "int 0x21"          \
    parm [dx]           \
    modify [ax dx];

void setdta( char far *dta )
{
    __dostdta( dta );
}
