#define __NO_INLINE_FUNCTIONS

#include <dos.h>

unsigned __doinprt( unsigned id );
#pragma aux __doinprt = \
    "in ax, dx"         \
    parm [dx]           \
    value [ax]          \
    modify [ax dx];

unsigned inport( unsigned id )
{
    return( __doinprt( id ) );
}
