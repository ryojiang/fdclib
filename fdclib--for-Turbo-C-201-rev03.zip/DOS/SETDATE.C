#include <dos.h>
#include <errno.h>

void __dosdatf( unsigned char day, unsigned char month, unsigned year );
#pragma aux __dosdatf = \
    "mov ah, 0x2B"      \
    "int 0x21"          \
    parm [dl] [dh] [cx] \
    modify [ax cx dx];

void setdate( struct date *ptr )
{
    __dosdatf( ptr->da_day, ptr->da_mon, ptr->da_year );
}
