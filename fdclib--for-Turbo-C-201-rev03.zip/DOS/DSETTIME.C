#include <dos.h>
#include <errno.h>

unsigned char __dosettm( unsigned char hour,
                         unsigned char minute,
                         unsigned char second,
                         unsigned char msecond );
#pragma aux __dosettm = \
    "mov ah, 0x2D"      \
    "int 0x21"          \
    parm [ch] [cl] [dh] [dl]\
    value [al]          \
    modify [ax cx dx];

unsigned _dos_settime( struct dostime_t *timeptr )
{
    if( __dosettm( timeptr->hour,
                   timeptr->minute,
                   timeptr->second,
                   timeptr->hsecond ) == 0xFF )
        return( ( errno = _doserrno = EINVAL ) );

    return( 0 );
}
