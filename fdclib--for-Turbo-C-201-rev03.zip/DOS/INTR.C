#include <dos.h>

/*
 * Borland/Watcom-alike intr function.  Use "void *" because a program
 * designed for Watcom would use "union REGPACK" and a program designed
 * for the Borland family of compilers would use "struct REGPACK".
 * Also, programs designed for this CLIB can also use "union _INTREGS" or
 * "union _INTR" (some compilers only).
 */
int intr( int intno, void *inoutregs )
{
    return( _callint( intno, inoutregs, inoutregs ) );
}

