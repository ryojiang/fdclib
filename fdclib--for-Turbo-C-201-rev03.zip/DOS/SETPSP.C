#include <dos.h>

void __dostpsp( unsigned psp );
#pragma aux __dostpsp = \
    "mov ah, 0x50"      \
    "int 0x21"          \
    parm [bx]           \
    modify [ax bx];

void setpsp( unsigned psp )
{
    __dostpsp( psp );
}
