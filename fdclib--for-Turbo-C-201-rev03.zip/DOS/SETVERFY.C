#include <dos.h>

void __dostvfy( unsigned char flag );
#pragma aux __dogtvfy = \
    "mov ah, 0x54"      \
    "int 0x21"          \
    parm [al]           \
    modify [ax];

void setverify( int flag )
{
    __dostvfy( ( unsigned char )flag );
}
