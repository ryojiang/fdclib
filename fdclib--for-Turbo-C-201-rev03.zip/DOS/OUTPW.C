#define __NO_INLINE_FUNCTIONS

#include <dos.h>

unsigned __dooutpt( unsigned id, unsigned value );
#pragma aux __dooutpt = \
    "out dx, ax"        \
    parm [dx] [ax]      \
    value [ax]          \
    modify [ax dx];

unsigned outpw( unsigned id, unsigned value )
{
    return( __dooutpt( id, value ) );
}
