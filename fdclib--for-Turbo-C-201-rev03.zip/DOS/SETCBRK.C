#include <dos.h>

void __doscbrk( unsigned char value );
#pragma aux __doscbrk = \
    "mov ax, 0x3301"    \
    "int 0x21"          \
    parm [dl]           \
    modify [ax dx];

int setcbrk( int value )
{
    __doscbrk( ( unsigned char )value );
    return( value );
}
