#include <dos.h>
#include <errno.h>

#ifdef __CLIB_LFN__
int __dolfnfn( unsigned intr,
               unsigned handle,
               unsigned char attrs,
               char *filename,
               void far *strptr );
#pragma aux __dolfnfn = \
    "mov si, 1"         \
    "stc"               \
    "int 0x21"          \
    "jnc finish"        \
    "mov errno, ax"     \
    "mov _doserrno, ax" \
    "sbb ax, ax"        \
    "finish:"           \
    parm [ax] [bx] [cl] [dx] [es di]\
    value [ax]          \
    modify [ax cx dx si di];

int __dolfncl( unsigned handle );
#pragma aux __dolfncl = \
    "mov ax, 0x71A1"    \
    "stc"               \
    "int 0x21"          \
    "jnc finish"        \
    "mov errno, ax"     \
    "mov _doserrno, ax" \
    "sbb ax, ax"        \
    "finish:"           \
    parm [bx]           \
    value [ax]          \
    modify [ax bx];
#endif

int __dofindf( unsigned char intr, int attrs, char *filename );
#pragma aux __dofindf = \
    "int 0x21"          \
    "jnc finish"        \
    "mov errno, ax"     \
    "mov _doserrno, ax" \
    "sbb ax, ax"        \
    "finish:"           \
    parm [ah] [cx] [dx] \
    value [ax]          \
    modify [ax cx dx];

#ifdef __CLIB_LFN__
#define _dos_findfirst __sfn_dos_findfirst
#define _dos_findnext __sfn_dos_findnext
#endif

unsigned _dos_findfirst( char *filename, int attrib, void *strptr )
{
    register int retval;

    setdta( strptr );
    if( ( retval = __dofindf( 0x4E, attrib, filename ) ) < 0 )
        return( _doserrno );

    return( 0 );
}

unsigned _dos_findnext( void *strptr )
{
    register int retval;

    setdta( strptr );
    if( ( retval = __dofindf( 0x4F, 0, NULL ) ) < 0 ) {
        return( _doserrno );
    }

    return( 0 );
}

#ifdef __CLIB_LFN__
#undef _dos_findfirst
#undef _dos_findnext
#undef _dos_findclose

unsigned _dos_findfirst( char *filename, int attr, void *strptr )
{
    register int retval;
    struct find_t *fblk = ( struct find_t * )strptr;
    struct __lfnfind temp;

    fblk->lfnhandle = 0xFFFF;

    if( ( retval = __dolfnfn( 0x714E, 0,
                   ( unsigned char )attr,
                   filename,
                   &temp ) ) < 0 ) {
        return( __sfn_dos_findfirst( filename, attr, fblk ) );
    }

    fblk->lfnhandle = retval;
    __convert_to_find( fblk, &temp );

    return( 0 );
}

unsigned _dos_findnext( void *strptr )
{
    register int retval;
    struct find_t *fblk = strptr;
    struct __lfnfind temp;

    if( fblk->lfnhandle == 0xFFFF ) return( __sfn_dos_findnext( strptr ) );

    if( ( retval = __dolfnfn( 0x714F, fblk->lfnhandle, 0, NULL, &temp ) ) < 0 )
        return( _doserrno );

    __convert_to_find( fblk, &temp );

    return( 0 );
}

unsigned _dos_findclose( void *strptr )
{
    register int retval;
    struct find_t *fblk = strptr;

    if( ( retval = __dolfncl( fblk->lfnhandle ) ) < 0 ) {
        return( _doserrno );
    }

    return( 0 );
}

#endif

