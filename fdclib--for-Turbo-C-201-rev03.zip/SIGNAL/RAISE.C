#include <signal.h>
#include <errno.h>

int raise( int sig )
{
    if( sig > 6 ) {
        errno = EINVAL;
        return( -1 );
    }

    ( __handlers[ sig ] )( sig );

    return( 0 );
}
