#include <io.h>

long filelength( int handle )
{
    long curpos = lseek( handle, 0L, SEEK_CUR ),
         retpos = lseek( handle, 0L, SEEK_END );

    lseek( handle, curpos, SEEK_SET );

    return( retpos );
}

