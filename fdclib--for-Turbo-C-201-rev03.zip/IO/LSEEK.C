#include <io.h>
#include <errno.h>

long __dolseek( int handle, long offset, unsigned char fromwhere );
#pragma aux __dolseek = \
    "mov ah, 0x42"      \
    "int 0x21"          \
    "jnc finish"        \
    "mov errno, ax"     \
    "sbb ax, ax"        \
    "finish:"           \
    parm [bx] [cx dx] [al] \
    value [dx ax]       \
    modify [ax bx cx dx];

off_t lseek( int handle, long offset, int fromwhere )
{
    long retval = 
        __dolseek( __oshandle( handle ), offset, ( unsigned char )fromwhere );

    if( retval < 0L )  return( -1L );

    return( retval );
}

