#include <dos.h>
#include <io.h>
#include <errno.h>

int __docrtmp( char *pathbuf, int attrib );
#pragma aux __docrtmp = \
    "mov ah, 0x5A"      \
    "int 0x21"          \
    "jnc finish"        \
    "sbb ax, ax"        \
    "finish:"           \
    parm [dx] [cx]      \
    value [ax]          \
    modify [ax cx dx];

int creattemp( char *pathbuf, int attrib )
{
    register int retval = __docrtmp( pathbuf, attrib );

    if( retval < 0 ) {
        errno = EACCES;
        return( -1 );
    }

    return( retval );
}
