#include <dos.h>
#include <fcntl.h>
#include <errno.h>
#include <io.h>

ssize_t write( int handle, const void *rdbuf, unsigned rdlen )
{
    int retval = 1, len = rdlen;
    const char *buf = rdbuf;

    while( len ) {
        if( ( handle & O_TEXT ) && *buf == '\n' )
            _write( __oshandle( handle ), "\r", 1 );

        retval = _write( __oshandle( handle ), buf, 1 );

        if( retval == 0 || retval == -1 ) break;

        len--;
        buf++;
    }

    return( len == rdlen ? -1 : rdlen - len );
}

