#include <dos.h>
#include <errno.h>

int __dowrite( int handle, const void *buf, unsigned len );
#pragma aux __dowrite = \
    "mov ah, 0x40"      \
    "int 0x21"          \
    "jnc finish"        \
    "mov errno, ax"     \
    "sub ax, ax"        \
    "finish:"           \
    parm [bx] [dx] [cx] \
    value [ax]          \
    modify [ax bx cx dx];

int _write( int handle, const void *buf, unsigned len )
{
    register int retval = __dowrite( handle, buf, len );

    if( retval < 0 ) return( -1 );

    return( retval );
}

