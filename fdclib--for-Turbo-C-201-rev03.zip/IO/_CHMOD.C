#include <dos.h>
#include <io.h>
#include <errno.h>
#include <stdarg.h>

int __dogsatr( unsigned char func, const char *filename, unsigned attrs );
#pragma aux __dogsatr = \
    "mov ah, 0x43"      \
    "int 0x21"          \
    "jnc finish"        \
    "mov errno, ax"     \
    "mov cx, 0xFFFF"    \
    "finish:"           \
    parm [al] [dx] [cx] \
    value [cx]          \
    modify [ax dx cx];

int _chmod( const char *filename, int func, ... )
{
    va_list args;
    register int retval;
    register int attrib;

    va_start( args, func );
    attrib = va_arg( args, int );

    if( ( retval =
          __dogsatr( ( unsigned char )func, filename, attrib ) ) < 0 ) {
        errno = ( func ) ? EACCES : ENOENT;
        return( -1 );
    }

    return( retval );
}
