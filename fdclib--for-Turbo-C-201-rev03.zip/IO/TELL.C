#include <io.h>

long tell( int handle )
{
    return( lseek( handle, 0L, SEEK_CUR ) );
}
