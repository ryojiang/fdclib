#include <io.h>
#include <fcntl.h>

extern unsigned __umask_perm;

unsigned umask( unsigned newmode )
{
    unsigned prev = __umask_perm;

    __umask_perm = newmode;

    return( prev );
}
