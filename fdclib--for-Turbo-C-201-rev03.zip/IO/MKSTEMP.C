#include <io.h>
#include <fcntl.h>
#include <sys/stat.h>

int mkstemp( char *template )
{
    register int handle;

    if( mktemp( template ) == NULL ) return( -1 );

    return( open( template, O_RDWR | O_CREAT | O_EXCL, S_IWRITE ) );
}
