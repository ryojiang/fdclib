#include <dos.h>
#include <errno.h>

int __dodread( int handle, void *buf, unsigned len );
#pragma aux __dodread = \
    "mov ah, 0x3F"      \
    "int 0x21"          \
    "jnc finish"        \
    "mov errno, ax"     \
    "sbb ax, ax"        \
    "finish:"           \
    parm [bx] [dx] [cx] \
    value [ax]          \
    modify [ax bx cx dx];

int _read( int handle, void *buf, unsigned len )
{
    register int retval = __dodread( handle, buf, len );

    if( retval < 0 ) return( -1 );

    return( retval );
}

