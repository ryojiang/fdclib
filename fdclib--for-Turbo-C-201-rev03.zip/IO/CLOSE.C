#include <dos.h>
#include <errno.h>
#include <io.h>

int __doclose( int handle );
#pragma aux __doclose = \
    "mov ah, 0x3E"      \
    "int 0x21"          \
    "sbb ax, ax"        \
    parm [bx]           \
    value [ax]          \
    modify [ax bx];

int close( int handle )
{
    if( __doclose( __oshandle( handle ) ) < 0 ) {
        errno = EBADF;
        return( -1 );
    }

    return( 0 );
}

