#include <io.h>
#include <errno.h>

int __dodup2( int handle, int handle2 );
#pragma aux __dodup2 =  \
    "mov ah, 0x46"      \
    "int 0x21"          \
    "jnc finish"        \
    "sbb ax, ax"        \
    "finish:"           \
    parm [bx] [cx]      \
    value [ax]          \
    modify [ax bx cx];

int dup2( int handle, int handle2 )
{
    register int retval = 
        __dodup2( __oshandle( handle ), __oshandle( handle2 ) );

    if( retval < 0 ) {
        errno = EMFILE;
        return( -1 );
    }

    return( 0 );
}
