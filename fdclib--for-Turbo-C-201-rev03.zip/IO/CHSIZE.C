#include <unistd.h>
#include <dos.h>

int chsize( int handle, long newsize )
{
    off_t curpos = lseek( handle, 0L, SEEK_CUR );
    int retval;

    if( curpos < 0 ) return( retval );

    if( lseek( handle, newsize, SEEK_SET ) == -1L )
        return( retval );

    retval = _write( handle, NULL, 0 );

    lseek( handle, curpos, SEEK_SET );

    return( retval );
}

