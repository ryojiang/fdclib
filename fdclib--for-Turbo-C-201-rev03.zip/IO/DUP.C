#include <io.h>
#include <errno.h>

int __dodup( int handle );
#pragma aux __dodup =   \
    "mov ah, 0x45"      \
    "int 0x21"          \
    "jnc finish"        \
    "sbb ax, ax"        \
    "finish:"           \
    parm [bx]           \
    value [ax]          \
    modify [ax bx];

int dup( int handle )
{
    register int retval = __dodup( __oshandle( handle ) );

    if( retval < 0 ) {
        errno = EMFILE;
        return( -1 );
    }

    return( retval );
}
