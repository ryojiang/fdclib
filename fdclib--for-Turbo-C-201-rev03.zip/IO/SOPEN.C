#include <io.h>
#include <stdarg.h>

int sopen( const char *name, int mode, int shflag, ... )
{
    va_list args;

    va_start( args, shflag );

    return( open( name, mode | shflag, va_arg( args, int ) ) );
}
