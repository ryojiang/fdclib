#include <io.h>
#include <fcntl.h>

int creat( const char *filename, int access )
{
    return( open( filename, O_CREAT|O_TRUNC|O_WRONLY, access ) );
}
