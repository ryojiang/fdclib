#include <io.h>

int isatty( int handle )
{
    register int retval = ioctl( handle, 0 );

    return( ( ( retval & 0x0080 ) || ( retval & 0x01 ) || ( retval & 0x02 ) ) );
}

