#include <fcntl.h>
#include <io.h>

void main( void )
{
    char buf[ 4096 ];

    gets( buf );
//    printf( "%i\n", read( 0, buf, 4096 ) );
}

