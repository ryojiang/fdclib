#include <dos.h>
#include <stdarg.h>
#include <errno.h>
#include <io.h>
/*
#ifdef __SMALL__
*/
int __doioctl( unsigned char func, int handle, void *argp, int argi );
#pragma aux __doioctl = \
    "mov ah, 0x44"      \
    "int 0x21"          \
    "jnc finish"        \
    "mov errno, ax"     \
    "mov dx, 0xFFFF"    \
    "finish:"           \
    parm [al] [bx] [dx] [cx]\
    value [dx]          \
    modify [ax bx cx dx];
/*
#else
#error "You can't build this with any other memory model at this time"
#endif
*/
int ioctl( int handle, int func, ... )
{
    va_list args;
    register char *argp;
    register int argi;
    register int retval;

    va_start( args, func );

    argp = va_arg( args, char * );
    argi = va_arg( args, int );

    return( ( retval =
                __doioctl( func, __oshandle( handle ), argp, argi ) ) < 0 ?
                -1 :
                retval );
}

