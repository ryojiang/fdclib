#include <io.h>
#include <errno.h>

int __doulock( int handle, long *offset, long *length );
#pragma aux __doflock = \
    "mov ax, 0x5C00"    \
    "int 0x21"          \
    "jnc finish"        \
    "mov errno, ax"     \
    "sbb ax, ax"        \
    "finish:"           \
    parm [bx] [dx] [di] \
    value [ax]          \
    modify [ax bx dx di];

int unlock( int handle, long offset, long length )
{
    register int retval = __doulock( __oshandle( handle ), &offset, &length );

    if( retval < 0 ) return( -1 );

    return( 0 );
}

