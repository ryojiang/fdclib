#include <dos.h>
#include <errno.h>

int __dodopen( const char *path, unsigned char flags );
#pragma aux __dodopen = \
    "mov ah, 0x3D"      \
    "int 0x21"          \
    "jnc finish"        \
    "mov errno, ax"     \
    "sbb ax, ax"        \
    "finish:"           \
    parm [dx] [al]      \
    value [ax]          \
    modify [ax cx bx dx];

#undef _dos_open

int _open( const char *path, int flags )
{
    register int retval = __dodopen( __retsfn( path ), ( unsigned char )flags );

    if( retval < 0 ) return( -1 );

    return( retval );
}
