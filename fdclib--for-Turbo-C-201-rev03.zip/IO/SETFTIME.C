#include <dos.h>
#include <errno.h>
#include <io.h>

int __dosetft( int handle, void *ptr );
#pragma aux __dosetft = \
    "mov cx, [di]"      \
    "mov dx, 2[di]"     \
    "mov ax, 0x5701"    \
    "int 0x21"          \
    "sbb ax, ax"        \
    parm [bx] [di]      \
    value [ax]          \
    modify [ax bx cx dx di];

int setftime( int handle, void *ptr )
{
    register int retval = __dosetft( __oshandle( handle ), ptr );

    if( retval < 0 ) {
        errno = EBADF;
        return( -1 );
    }

    return( 0 );
}
