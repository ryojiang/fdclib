#include <io.h>
#include <stdlib.h>
#include <string.h>

void _assert( char *expr, char *file, int line )
{
    char itoabuf[ 32 ];

    itoa( line, itoabuf, 10 );
    write( 2, "Assertion Failed: ", 18 );
    write( 2, expr, strlen( expr ) );
    write( 2, ", file ", 7 );
    write( 2, file, strlen( file ) );
    write( 2, ", line ", 7 );
    write( 2, itoabuf, strlen( itoabuf ) );
    write( 2, ".\n", 2 );

    abort();
}

