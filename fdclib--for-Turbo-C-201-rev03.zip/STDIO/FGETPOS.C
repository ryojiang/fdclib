#include <stdio.h>
#include <io.h>

int fgetpos( FILE *fp, fpos_t *pos )
{
    if( ( *pos = lseek( fp->fd, 0L, SEEK_CUR ) ) == -1L ) {
        fp->flags |= __FERROR;
        return( -1 );
    }

    if( fp->unget && *pos != 0 ) *pos = ( *pos - 1 );

    return( 0 );
}

