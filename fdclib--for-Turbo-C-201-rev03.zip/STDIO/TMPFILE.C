#include <stdio.h>
#include <malloc.h>
#include <io.h>
#include <dir.h>

FILE *tmpfile( void )
{
    char *tempname = tempnam( ".", NULL );
    FILE *retval;

    if( tempname == NULL ) return( NULL );

    if( ( retval = fopen( tempname, "w+b" ) ) == NULL ) {
        free( tempname );

        return( NULL );
    }

    retval->tempfnam = malloc( strlen( tempname ) + 1 );
    strcpy( retval->tempfnam, tempname );

    return( retval );
}

