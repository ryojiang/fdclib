#include <stdio.h>
#include <io.h>

extern FILE *__openstreams[];

int rmtmp( void )
{
    int i = 0, j = 0;

    while( __openstreams[ j ] ) {
        if( __openstreams[ j ]->tempfnam != NULL ) {
            if( fclose( __openstreams[ j ] ) != 0 ) return( EOF );
            i++;
        }
        j++;
    }

    return( i );
}
