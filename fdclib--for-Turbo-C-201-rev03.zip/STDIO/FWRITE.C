#include <stdio.h>
#include <io.h>
#include <stddef.h>

size_t fwrite( const void * restrict ptr, size_t ilen, size_t items,
               FILE * restrict fp )
{
    int retval = write( fp->fd, ptr, ilen * items );

    if( retval == -1 ) fp->flags |= __FERROR;

    return( ( retval / ilen ) );
}

