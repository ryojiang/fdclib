#include <stdio.h>

char *ctermid( char *s )
{
    static char cname[ 4 ] = "CON";

    if( s ) return( strcpy( s, cname ) );

    return( cname );
}

