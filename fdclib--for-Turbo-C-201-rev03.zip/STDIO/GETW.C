#include <stdio.h>
#include <io.h>

int getw( FILE *fp )
{
    int ch;
    if( _read( fp->fd, &ch, 2 ) == -1 ) {
        fp->flags |= __FEOF;
        return( EOF );
    }

    return( ch );
}
