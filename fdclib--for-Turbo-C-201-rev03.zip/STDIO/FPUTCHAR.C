#include <stdio.h>
#include <io.h>

int fputchar( int ch )
{
    if( ch == '\n' ) fputchar( '\r' );
    if( write( 1, &ch, 1 ) == -1 ) {
        return( EOF );
    }

    return( ch );
}
