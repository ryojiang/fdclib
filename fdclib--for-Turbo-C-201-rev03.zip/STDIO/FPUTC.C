#include <stdio.h>
#include <io.h>

int fputc( int ch, FILE *fp )
{
    if( ( fp->flags & __FTEXT ) && ch == '\n' ) fputc( '\r', fp );
    if( _write( fp->fd, &ch, 1 ) == -1 ) {
        fp->flags |= __FERROR;
        return( EOF );
    }

    return( ch );
}

