#include <stdio.h>
#include <io.h>
#include <string.h>

int fputs( const char *string, FILE *fp )
{
    register int retval = write( fp->fd,
                                 ( void * )string, strlen( string ) );
    if( retval == -1 ) {
        fp->flags |= __FERROR;
        return( EOF );
    }

    return( ( int )string[ retval ] );
}

