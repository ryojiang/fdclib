#include <stdio.h>
#include <io.h>

long ftell( FILE *fp )
{
    long retval = tell( fp->fd );

    if( retval == -1L ) {
        fp->flags |= __FERROR;
        return( -1L );
    }

    if( fp->unget && retval != 0 ) retval--;

    return( retval );
}

