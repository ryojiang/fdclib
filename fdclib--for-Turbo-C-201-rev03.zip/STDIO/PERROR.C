#include <stdio.h>
#include <errno.h>
#include <string.h>

void perror( const char *string )
{
    fputs( _strerror( string ), stderr );
}
