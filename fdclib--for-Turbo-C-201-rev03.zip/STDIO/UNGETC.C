#include <stdio.h>

int ungetc( int c, FILE *stream )
{
    if( stream->unget ) return( -1 );

    stream->unget = c;

    return( c );
}

