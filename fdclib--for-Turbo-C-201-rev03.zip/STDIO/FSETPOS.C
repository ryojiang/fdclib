#include <stdio.h>
#include <io.h>

int fsetpos( FILE *fp, const fpos_t *pos )
{
    if( lseek( fp->fd, *pos, SEEK_SET ) != *pos ) {
        fp->flags |= __FERROR;
        return( -1 );
    }

    fp->unget = 0;

    return( 0 );
}

