#include <stdio.h>
#include <io.h>
#include <string.h>

char *fgets( char *string, int num, FILE *fp )
{
    int ch;
    char *s = string;

    if( __oshandle( fp->fd == 0 ) ) {
        gets_s( string, num - 1 );

        if( string != NULL ) strcat( string, "\n" );

        return( string );
    }

    while( num-- ) {
        *s = ch = fgetc( fp );
        if( *s == '\n' ) {
            s++;

            break;
        }

        if( ch == EOF ) { /* *s can never be a negative value */
            *s = '\0';
            fp->flags |= __FEOF;
            return( NULL );
        }

        s++;
    }

    *s = '\0';

    return( string );
}

