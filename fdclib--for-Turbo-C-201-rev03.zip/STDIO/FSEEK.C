#include <stdio.h>
#include <io.h>

int fseek( FILE *fp, long offset, int loc )
{
    if( lseek( fp->fd, offset, loc ) == -1L ) {
        fp->flags |= __FERROR;
        return( -1 );
    }

    fp->unget = 0;

    return( 0 );
}

