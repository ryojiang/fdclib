#include <stdio.h>
#include <io.h>

extern FILE *__openstreams[];

int fcloseall( void )
{
    int i = 0;

    while( i <= HANDLE_MAX ) {
        if( __openstreams[ i ] &&
            fclose( __openstreams[ i ] ) != 0 ) return( EOF );
        i++;
    }

    return( i - 1 );
}
