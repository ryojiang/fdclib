#include <stdio.h>
#include <io.h>

int putw( int ch, FILE *fp )
{
    if( _write( fp->fd, &ch, 2 ) == -1 ) {
        fp->flags |= __FERROR;
        return( EOF );
    }

    return( ch );
}
