#include <io.h>
#include <stdio.h>
#include <malloc.h>

int fclose( FILE *fp )
{
    register int retval = close( fp->fd );

    if( fp->tempfnam ) {
        unlink( fp->tempfnam );
        free( fp->tempfnam );
    }

    free( fp );

    return( ( retval == -1 ) ? EOF : 0 );
}

