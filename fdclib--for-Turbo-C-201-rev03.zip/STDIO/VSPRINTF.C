#include <stdio.h>
#include <_printf.h>
#include <stdarg.h>
#include <string.h>

static char *__prntstrng;

int __putschar( int ch )
{
    char *p = __prntstrng;

    while( *p ) p++;

    *p = ch;
    p++;
    *p = '\0';

    return( ch );
}

int vsprintf( char *string, const char *fmt, va_list args )
{
    __prntstrng = string;
    *__prntstrng = '\0';

    return( __vfnprintf( __putschar, fmt, args ) );
}

int sprintf( char *string, const char *fmt, ... )
{
    va_list args;

    va_start( args, fmt );
    return( vsprintf( string, fmt, args ) );
}
