#include <stdio.h>
#include <io.h>

void rewind( FILE *fp )
{
    lseek( fp->fd, 0L, SEEK_SET );

    fp->flags = 0;
    fp->unget = 0;
}

