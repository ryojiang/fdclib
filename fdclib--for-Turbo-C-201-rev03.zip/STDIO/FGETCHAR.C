#include <stdio.h>
#include <io.h>

unsigned char __getchwe( void );
#pragma aux __getchwe = \
    "mov ah, 0x01"      \
    "int 0x21"          \
    value [al]          \
    modify [ax];

int fgetchar( void )
{
    int ch = __getchwe();

    if( ch == '\r' ) return( '\n' );
    if( ch == '\b' ) {
        fputchar( ' ' );
        fputchar( '\b' );
    }

    return( ch );
}

