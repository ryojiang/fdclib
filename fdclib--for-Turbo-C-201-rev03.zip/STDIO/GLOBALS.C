#include <stdio.h>
#include <string.h>

FILE *__openstreams[ 20 ] = { NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
                              NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
                              NULL, NULL, NULL, NULL };
FILE __stdin_stream = { 0, 0, 0, NULL },
     __stdout_stream = { 1, 0, 0, NULL },
     __stderr_stream = { 2, 0, 0, NULL },
     __stdaux_stream = { 3, 0, 0, NULL },
     __stdprn_stream = { 4, 0, 0, NULL };
