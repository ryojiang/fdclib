#include <stdio.h>
#include <io.h>
#include <string.h>

int puts( const char *string )
{
    register int retval = _write( 1, ( void * )string, strlen( string ) );

    if( retval == -1 ) return( EOF );

    _write( 1, "\n", 1 );

    return( 1 );
}

