#include <stdio.h>
#include <io.h>

int fgetc( FILE *fp )
{
    int ch;
    register int retval;

    if( fp->fd == 0 ) return( fgetchar() );

    if( fp->unget ) {
        retval = fp->unget;

        fp->unget = 0;

        return( retval );
    }

    retval = read( fp->fd, &ch, 1 );
    if( retval == -1 || retval == 0 ) {
        fp->flags |= __FEOF;
        return( EOF );
    }

    return( ch );
}

