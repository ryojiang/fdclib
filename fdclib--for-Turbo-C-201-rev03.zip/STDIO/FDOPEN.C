#include <stdio.h>
#include <io.h>
#include <malloc.h>
#include <fcntl.h>

extern FILE *__openstreams[];

FILE *fdopen( int handle, const char *mode )
{
    int i, tmpmode = __getomode( mode );
    FILE *retval = malloc( sizeof( FILE ) );

    if( retval == NULL ) return( NULL );

    retval->fd = handle;
    retval->tempfnam = NULL;
    retval->flags = retval->unget = 0;

    if( tmpmode & O_BINARY ) retval->flags &= ~__FTEXT;
    else retval->flags |= __FTEXT;

    for( i = 0; __openstreams[ i ]; i++ );
    if( i > HANDLE_MAX ) {
        free( retval );

        return( NULL );
    }
    __openstreams[ i ] = retval;

    return( retval );
}
