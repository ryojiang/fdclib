#include <stdio.h>
#include <_printf.h>
#include <stdarg.h>

int vprintf( const char *fmt, va_list args )
{
    return( __vfnprintf( putchar, fmt, args ) );
}

int printf( const char *fmt, ... )
{
    va_list args;
    
    va_start( args, fmt );;
    return( vprintf( fmt, args ) );
}
