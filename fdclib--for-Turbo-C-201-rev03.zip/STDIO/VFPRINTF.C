#include <stdio.h>
#include <_printf.h>
#include <stdarg.h>

static FILE *__prntfile;

int __putfchar( int ch )
{
    return( fputc( ch, __prntfile ) );
}

int vfprintf( FILE *fp, const char *fmt, va_list args )
{
    __prntfile = fp;

    return( __vfnprintf( __putfchar, fmt, args ) );
}

int fprintf( FILE *fp, const char *fmt, ... )
{
    va_list args;

    va_start( args, fmt );
    return( vfprintf( fp, fmt, args ) );
}
