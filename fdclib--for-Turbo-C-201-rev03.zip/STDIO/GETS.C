#include <stdio.h>
#include <io.h>
#include <string.h>

struct __inpbuf {
    unsigned char numchars;
    unsigned char charsread;
    char buf[ 255 ];
};

void __getinpt( struct __inpbuf *buffer );
#pragma aux __getinpt = \
    "mov ah, 0x0A"      \
    "int 0x21"          \
    parm [dx]           \
    modify [ax dx];

char *gets( char *string )
{
    struct __inpbuf inpbuf;

    inpbuf.numchars = 254;
    inpbuf.charsread = 0;

    __getinpt( &inpbuf );

    fputchar( '\n' );

    return( strncpy( string, inpbuf.buf, inpbuf.charsread ) );
}

