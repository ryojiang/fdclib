#include <stdlib.h>

extern const char __basechars[];

char *ltoa( long val, char *buf, int base )
{
    if( base > 36 || base < 2 ) {
          *buf = '\0';
          return( buf );
    }
    if( val < 0 ) *buf++ = '-';

    val = labs( val );

    if( ( val / base ) > 0 ) buf = ltoa( ( val / base ), buf, base );

    *buf++ = __basechars[ ( int )( val % base ) ];
    *buf = '\0';

    return( buf );
}

