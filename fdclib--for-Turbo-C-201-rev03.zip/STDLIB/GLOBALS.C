#include <stdlib.h>

const char __basechars[] = "0123456789ABCDEF";

