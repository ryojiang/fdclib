#include <stdlib.h>
#include <string.h>

#define __MAXEXIT   32

extern void ( *__userexit[ __MAXEXIT ] )( void );
extern int __atexited;

int atexit( void ( *func )( void ) )
{
    int x;

    if( !__atexited ) memset( __userexit, NULL, 32 );
    for( x = 0; x < __MAXEXIT; x++ ) {
        if( __userexit[ x ] == NULL ) {
            __userexit[ x ] = func;
            return( 0 );
        }
    }
    
    return( -1 );
}

