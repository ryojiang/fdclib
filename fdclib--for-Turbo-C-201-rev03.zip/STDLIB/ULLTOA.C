#include <stdlib.h>

extern const char __basechars[];

char *ulltoa( unsigned long long val, char *buf, int base )
{
    if( base > 36 || base < 2 ) {
          *buf = '\0';
          return( buf );
    }

    if( ( val / base ) > 0 ) buf = ulltoa( ( val / base ), buf, base );

    *buf++ = __basechars[ ( int )( val % base ) ];
    *buf = '\0';

    return( buf );
}

