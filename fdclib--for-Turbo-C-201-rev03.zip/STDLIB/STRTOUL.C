#include <stdlib.h>
#include <ctype.h>

unsigned long strtoul( const char *nptr, char **endptr, int base )
{
    unsigned long x = 0;
    
    for( ;; ) {
        if( isdigit( *nptr ) ) {
            x = x * base + ( *nptr - '0' );
            nptr++;
        } else if( isalpha( *nptr ) && ( base > 10 ) ) {
            x = x * base + ( toupper( *nptr ) - 'A' ) + 10;
            nptr++;
        } else {
            break;
        }
    }
    if( endptr != NULL ) {
        *endptr = ( char * )nptr;
    }

    return( x );
}

