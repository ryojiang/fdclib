#include <stdlib.h>
#include <string.h>

int unsetenv( const char *name )
{
    char *envstring = malloc( strlen( name ) + 2 );
    register int retval;

    if( envstring == NULL ) return( -1 );

    strcpy( envstring, name );
    strcat( envstring, "="  );

    retval = putenv( envstring );

    free( envstring );

    return( retval );
}

