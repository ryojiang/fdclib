#include <stdlib.h>
#include <ctype.h>

long strtol( const char *nptr, char **endptr, int base )
{
    long x = 0;
    char undecided = 0, neg = 0;
    
    if( base == 0 ) undecided = 1;

    if( *nptr == '-' ) neg = 1;

    for( ;; ) {
        if( isdigit( *nptr ) ) {
            if( base == 0 ) {
                if( *nptr == '0' ) base = 8;
                else {
                    base = 10;
                    undecided = 0;
                }
            }
            x = x * base + ( *nptr - '0' );
            nptr++;
        } else if( isalpha( *nptr ) ) {
            if( ( *nptr == 'X' ) || ( *nptr == 'x' ) ) {
                if( ( base == 0 ) || ( ( base == 8 ) && undecided ) ) {
                    base = 16;
                    undecided = 0;
                } else {
                    break;
                }
            } else {
                x = x * base + ( toupper( *nptr ) - 'A' ) + 10;
                nptr++;
            }
        } else {
            break;
        }
    }
    if( endptr != NULL ) {
        *endptr = ( char * )nptr;
    }

    if( neg ) x = -x;

    return( x );
}

