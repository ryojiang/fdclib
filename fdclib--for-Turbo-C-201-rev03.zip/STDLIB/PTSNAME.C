#include <stdlib.h>
#include <io.h>

static char conname[] = "CON";

char *ptsname( int fildes )
{
    if( isatty( fildes ) ) return( conname );
    
    return( NULL );
}

