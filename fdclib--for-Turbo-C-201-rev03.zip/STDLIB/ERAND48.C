#include <stdlib.h>

extern unsigned short __rand48buf[ 3 ];
extern void __calc_next( unsigned short buf[ 3 ] );

double erand48( unsigned short buf[ 3 ] )
{
    double ret;

    ret = ( ( buf[ 0 ] / 65536.0 + buf[ 1 ] ) / 65536.0 + buf[ 2 ] ) / 65536.0;
    __calc_next( buf );

    return( ret );
}

double drand48( void )
{
    return( erand48( __rand48buf ) );
}

