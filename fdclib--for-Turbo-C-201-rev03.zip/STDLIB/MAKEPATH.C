#include <dir.h>
#include <string.h>

void _makepath( char *path, const char *drive, const char *dir,
                            const char *fname, const char *ext )
{
    if( *drive ) {
        strcpy( path, drive );
        if( !drive[ 1 ] ) strcat( path, ":" );
    } else ( *path ) = 0;
    
    if( *dir ) {
        strcat( path, dir );
        if( *( dir + strlen( dir ) - 1 ) != '\\' )
            strcat( path, "\\" );
    }
    
    if( *fname ) {
        strcat( path, fname );
        if( *ext ) {
            if( *ext != '.' ) strcat( path, "." );
            strcat( path, ext );
        }
    }
}

