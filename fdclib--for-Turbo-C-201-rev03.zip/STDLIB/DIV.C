#include <stdlib.h>
#include <stddef.h>

div_t div( int num, int denom )
{
    div_t retval;

    retval.quot = num / denom;
    retval.rem = num % denom;

    return( retval );
}
