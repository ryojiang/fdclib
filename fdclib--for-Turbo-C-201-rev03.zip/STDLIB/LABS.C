#include <stdlib.h>

long labs( long num )
{
    return( ( num < 0 ) ? - num : num );
}
