#include <stdlib.h>

int rand_r( unsigned *seed )
{
    srand( *seed );

    return( rand() );
}

