#include <stdlib.h>
#include <dos.h>
#include <ctype.h>
#include <string.h>

char *getenv( const char *name )
{
    int i;

    for( i = 0; environ[ i ]; i++ ) {
        if( strnicmp( environ[ i ], name, strlen( name ) ) == 0 ) return( environ[ i ] + strlen( name ) + 1 );
    }

    return( NULL );
}

