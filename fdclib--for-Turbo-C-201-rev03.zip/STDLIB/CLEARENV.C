#include <stdlib.h>

int clearenv( void )
{
    int i = 0;

    for( ; environ[ i ]; i++ ) free( environ[ i ] );

    free( environ );

    if( ( environ = malloc( 3 ) ) == NULL ) return( -1 );

    return( 0 );
}

