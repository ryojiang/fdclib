#define __HAVE_LONG_LONG__

#include <stdlib.h>
#include <stddef.h>

lldiv_t lldiv( long long num, long long denom )
{
    lldiv_t retval;

    retval.quot = num / denom;
    retval.rem = num % denom;

    return( retval );
}

