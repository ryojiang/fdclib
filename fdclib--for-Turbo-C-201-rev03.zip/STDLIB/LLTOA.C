#include <stdlib.h>

extern const char __basechars[];

char *lltoa( long long val, char *buf, int base )
{
    if( base > 36 || base < 2 ) {
          *buf = '\0';
          return( buf );
    }
    if( val < 0 ) *buf++ = '-';

    val = llabs( val );

    if( ( val / base ) > 0 ) buf = lltoa( ( val / base ), buf, base );

    *buf++ = __basechars[ ( int )( val % base ) ];
    *buf = '\0';

    return( buf );
}

