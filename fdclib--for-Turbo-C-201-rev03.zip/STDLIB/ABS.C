#include <stdlib.h>

int abs( int num )
{
    return( ( num < 0 ) ? - num : num );
}
