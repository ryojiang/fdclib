#include <stdlib.h>
#include <stddef.h>

ldiv_t ldiv( long num, long denom )
{
    ldiv_t retval;

    retval.quot = num / denom;
    retval.rem = num % denom;

    return( retval );
}
