#include <stdlib.h>

long long llabs( long long num )
{
    return( ( num < 0 ) ? - num : num );
}
